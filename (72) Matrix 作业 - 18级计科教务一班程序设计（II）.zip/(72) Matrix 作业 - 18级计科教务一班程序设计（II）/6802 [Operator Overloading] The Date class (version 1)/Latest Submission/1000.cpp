class Date
{
public:
  Date(int y=0, int m=1, int d=1){
  	year = y;
  	month = m;
  	day = d;
  }
   static bool leapyear(int year){
   		if( ((year%4 == 0)&&(year%100 != 0))||(year%400 == 0) ) return 1;
  		else return 0;
   }
  int getYear() const{
  	return year;
  }
  int getMonth() const{
  	return month;
  }
  int getDay() const{
  	return day;
  }
  int operator ==(const Date& b){
  	if((year == b.year)&&(month == b.month)&&(day == b.day)) return 1;
  	return 0;
  }
  int operator <=(const Date& b){
  	if(*this == b) return 1;
  	else if(year < b.year) return 1;
  	else if(year == b.year){
  		if(month < b.month) return 1;
  		else if(month == b.month){
  			if(day < b.day) return 1;
		  }
	  }
	  return 0;
  }
int operator >=(const Date& b){
	if(*this == b) return 1;
  	else if(year > b.year) return 1;
  	else if(year == b.year){
  		if(month > b.month) return 1;
  		else if(month == b.month){
  			if(day > b.day) return 1;
		  }
	  }
	  return 0;
}
int operator !=(const Date& b){
	if((year != b.year)||(month != b.month)||(day != b.day)) return 1;
	return 0;
}
int operator >(const Date& b){
	 if(year > b.year) return 1;
  	else if(year == b.year){
  		if(month > b.month) return 1;
  		else if(month == b.month){
  			if(day > b.day) return 1;
		  }
	  }
	  return 0;
}
int operator <(const Date& b){
	if(year < b.year) return 1;
  	else if(year == b.year){
  		if(month < b.month) return 1;
  		else if(month == b.month){
  			if(day < b.day) return 1;
		  }
	  }
	  return 0;
}
private:
	int year;
	int month;
	int day;

  // add any member you need here  
};
