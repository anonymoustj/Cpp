#include<iostream>

class Date
{
    public:
        Date(int newYear,int newMonth,int newDay);
        int getYear();
        void setYear(int newYear);
        int getMonth();
        int getDay();
        void setMonth(int Month);
        void setDay(int Day);

  private:
        int year;
        int month;
        int day;
};

class Person
{
public:
  Person(int id, int year, int month, int day);
  Person(const Person &); // copy constructor
  ~Person();
  int getId();
  Date * getBirthDate();
  static int getNumberOfObjects(); //return the number of Person objects 

private:
  int id;
  Date *birthDate; 
  static int numberOfObjects; //count the number of Person objects
};
int Person::numberOfObjects=0;
Date::Date(int newYear,int newMonth,int newDay)
{
	year=newYear;
	month=newMonth;
	day=newDay;
}
int Date::getYear()
{
	return year;
}
int Date::getMonth()
{
	return month;
}
int Date::getDay()
{
	return day;
}
void Date::setYear(int newYear)
{
	year=newYear;
}
void Date::setMonth(int newMonth)
{
	month=newMonth;
}
void Date::setDay(int newDay)
{
	day=newDay;
}

Person::Person(int id, int year, int month, int day)
{
	Person::id=id;
	birthDate=new Date(year,month,day);
  numberOfObjects++;
  
}
Person::Person(const Person &person)
{
	id=person.id;
	birthDate=new Date(person.birthDate->getYear(),person.birthDate->getMonth(),person.birthDate->getDay());
	numberOfObjects++;

}
int Person::getId()
{
	return id;
}
Date * Person::getBirthDate()
{
	return birthDate;

}
int Person::getNumberOfObjects()
{
	return numberOfObjects;
}
Person::~Person()
{
	delete birthDate;
  numberOfObjects--;
}