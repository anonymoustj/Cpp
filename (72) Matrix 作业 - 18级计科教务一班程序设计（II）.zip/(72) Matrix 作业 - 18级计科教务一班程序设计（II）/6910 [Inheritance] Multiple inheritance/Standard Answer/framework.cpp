#include "source.h"
int main()
{
 {
 Weekend end;
 Workday day;
    }
}