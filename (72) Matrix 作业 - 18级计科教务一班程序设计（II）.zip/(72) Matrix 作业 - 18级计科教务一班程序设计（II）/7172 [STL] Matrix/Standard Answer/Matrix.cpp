#include "Matrix.hpp"
#include <iostream>

using namespace std;


void Matrix::resize(int nrow, int ncol) {
  data.resize(nrow);
  for (int i = 0; i < data.size(); i++) {
    data[i].resize(ncol);
  }
}

std::pair<int, int> Matrix::size() const {
  int row = data.size();
  int col = 0;
  if (row != 0) {
    col = data[0].size();
  }
  return make_pair(row, col);
}

std::vector<int>& Matrix::operator[](int r) throw(std::out_of_range) {
  if (r < 0 || r >= data.size()) {
    throw out_of_range("");
  }
  return data[r];
}

const std::vector<int>& Matrix::operator[](int r) const throw(std::out_of_range)  {
  if (r < 0 || r >= data.size()) {
    throw out_of_range("");
  }
  return data[r];
}

Matrix Matrix::operator+(const Matrix& other) throw(std::invalid_argument) {
  if (other.size() != size()) {
    throw invalid_argument("");
  }
  if (data.size() == 0) { return Matrix(); }

  int row = data.size();
  int col = data[0].size();
  Matrix ret(row, col);
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      ret[i][j] = data[i][j] + other[i][j];
    }
  }
  return ret;
}


Matrix Matrix::operator-(const Matrix& other) throw(std::invalid_argument) {
  if (other.size() != size()) {
    throw invalid_argument("");
  }
  if (data.size() == 0) { return Matrix(); }

  int row = data.size();
  int col = data[0].size();
  Matrix ret(row, col);
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      ret[i][j] = data[i][j] - other[i][j];
    }
  }
  return ret;
}

// innerProduct
Matrix Matrix::operator*(const Matrix& other) throw(std::invalid_argument) {
  return innerProduct(other);
}

// dot products
Matrix Matrix::dotProduct(const Matrix& other) throw(std::invalid_argument) {
  if (other.size() != size()) {
    throw invalid_argument("");
  }
  if (data.size() == 0) { return Matrix(); }

  int row = data.size();
  int col = data[0].size();
  Matrix ret(row, col);
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      ret[i][j] = data[i][j] * other[i][j];
    }
  }
  return ret;
}

// inner products
Matrix Matrix::innerProduct(const Matrix& other) throw(std::invalid_argument) {
  int Arow = size().first;
  int Acol = size().second;
  int Brow = other.size().first;
  int Bcol = other.size().second;

  if (Acol != Brow) {
    throw invalid_argument("");
  }
  if (data.size() == 0) { return Matrix(); }

  Matrix ret(Arow, Bcol);
  for (int i = 0; i < Arow; i++) {
    for (int j = 0; j < Bcol; j++) {
      int ans = 0;
      for (int k = 0; k < Acol; k++) {
        ans += data[i][k] * other[k][j];
      }
      ret[i][j] = ans;
    }
  }
  return ret;
}

/**
 * For example: 3x3 identity matrix
 *   1 0 0
 *   0 1 0
 *   0 0 1
 */
void Matrix::print() {
  int row = size().first;
  int col = size().second;

  for (int i = 0; i < row; i++) {
    cout << data[i][0];
    for (int j = 1; j < col; j++) {
      cout << " " << data[i][j];
    }
    cout << endl;
  }
}
