#include"Matrix.hpp"
#include<iostream>
using namespace std;
void Matrix::resize(int nrow, int ncol)
{
	data.resize(nrow);
	int i=0;
	for(i=0;i<nrow;i++)
	{
		data[i].resize(ncol);
	}
}
std::pair<int, int> Matrix::size() const
{
	if(data.empty()==true)
	{
		return pair<int ,int >(0,0);
	}
	return pair<int ,int >(data.size(),data[0].size());
}
std::vector<int>& Matrix::operator[](int r) throw(std::out_of_range)
{
	
	if(r>=data.size())
	throw out_of_range("error");
	return data[r];
}
const std::vector<int>& Matrix::operator[](int r) const throw(std::out_of_range)
{
	
	if(r>=data[0].size())
	throw out_of_range("error");
	
	return data[r];
}
Matrix Matrix::operator+(const Matrix& other) throw(std::invalid_argument)
{
	if(data.empty()==true)
	return Matrix(0,0);
	if(data.size()!=other.data.size()||data[0].size()!=other.data[0].size())
	throw invalid_argument("error");
	Matrix temp(data.size(),data[0].size());
	int i,j;
	for(i=0;i<data.size();i++)
	{
		for(j=0;j<data[0].size();j++)
		{
			temp.data[i][j]=data[i][j]+other.data[i][j];
		}
	}
	return temp;
}
Matrix Matrix::operator-(const Matrix& other) throw(std::invalid_argument)
{
	if(data.empty()==true)
	return Matrix(0,0);
	if(data.size()!=other.data.size()||data[0].size()!=other.data[0].size())
	throw invalid_argument("error");
	Matrix temp(data.size(),data[0].size());
	int i,j;
	for(i=0;i<data.size();i++)
	{
		for(j=0;j<data[0].size();j++)
		{
			temp.data[i][j]=data[i][j]-other.data[i][j];
		}
	}
	return temp;
}
Matrix Matrix::operator*(const Matrix& other) throw(std::invalid_argument)
{
	if(data.empty()==true)
	return Matrix(0,0);
	if(data[0].size()!=other.data.size())
	throw invalid_argument("error");
	Matrix temp(data.size(),other.data[0].size());
	int i,j,k;
	for(i=0;i<data.size();i++)
	{
		for(j=0;j<other.data[0].size();j++)
		{
			temp.data[i][j]=0;
		}
	}
 	for(i=0;i<other.data[0].size();i++)
 	{
 		for(j=0;j<other.data.size();j++)
 		{
			for(k=0;k<data.size();k++)
			{
				temp.data[k][i]+=(data[k][j]*other.data[j][i]);
			}
		 }
	 }
	 return temp;
}
Matrix Matrix::dotProduct(const Matrix& other) throw(std::invalid_argument)
{
	if(data.empty()==true)
	return Matrix(0,0);
	if(data.size()!=other.data.size()||data[0].size()!=other.data[0].size())
	throw invalid_argument("error");
	Matrix temp(data.size(),data[0].size());
	int i,j;
	for(i=0;i<data.size();i++)
	{
		for(j=0;j<data[0].size();j++)
		{
			temp.data[i][j]=data[i][j]*other.data[i][j];
		}
	}
	return temp;
}
Matrix Matrix::innerProduct(const Matrix& other) throw(std::invalid_argument)
{
	if(data.empty()==true)
	return Matrix(0,0);
	if(data[0].size()!=other.data.size())
	throw invalid_argument("error");
	Matrix temp(data.size(),other.data[0].size());
	int i,j,k;
	for(i=0;i<data.size();i++)
	{
		for(j=0;j<other.data[0].size();j++)
		{
			temp.data[i][j]=0;
		}
	}
 	for(i=0;i<other.data[0].size();i++)
 	{
 		for(j=0;j<other.data.size();j++)
 		{
			for(k=0;k<data.size();k++)
			{
				temp.data[k][i]+=(data[k][j]*other.data[j][i]);
			}
		 }
	 }
	 return temp;
}
void Matrix::print()
{
	if(data.empty()==true)
	return;
	int i,j;
	for(i=0;i<data.size();i++)
	{
		for(j=0;j<data[0].size()-1;j++)
		{
			cout<<data[i][j]<<" ";
		}
		cout<<data[i][j]<<endl;
	}
}
