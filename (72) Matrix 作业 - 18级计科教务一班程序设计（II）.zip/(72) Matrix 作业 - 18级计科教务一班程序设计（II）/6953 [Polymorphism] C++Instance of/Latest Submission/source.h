#include <iostream>
#include <string>

using namespace std;
class Object
{
	public:
	virtual string re(void)
	{
		return "Object";
	};
};
 
class Animal:public Object
{
	public:
	string re(void)
	{
		return "Animal";
	};
};
class Dog:public Animal
{
	public:
	string re(void)
	{
		return "Dog";
	};
};
class Cat:public Animal
{
	public:
	string re(void)
	{
		return "Cat";
	};
};
 
class Vehicle:public Object
{
	public:
	string re(void)
	{
		return "Vehicle";
	};
};
class Bus:public Vehicle
{
	public:
	string re(void)
	{
		return "Bus";
	};
};
class Car:public Vehicle
{
	public:
	string re(void)
	{
		return "Car";
	};
};
 
class Person:public Object
{
	public:
	string re(void)
	{
		return "Person";
	};
};
class Student:public Person
{
	public:
	string re(void)
	{
		return "Student";
	};
};
class Teacher:public Person
{
	public:
	string re(void)
	{
		return "Teacher";
	};
};
string instanceof(Object& obj)
{
	if(&obj==NULL)
	{
		return "NULL";
	}
	else
	{
		return obj.re();
	}
};