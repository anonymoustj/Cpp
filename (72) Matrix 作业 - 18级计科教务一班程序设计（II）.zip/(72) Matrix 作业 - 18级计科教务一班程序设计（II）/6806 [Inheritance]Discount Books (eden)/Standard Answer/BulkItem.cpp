#include "BulkItem.h"
#include <iostream>
using std::string;
 BulkItem::BulkItem(const string& bookName,
        double salesPrice, int qty,
        double salesDisc) : BookItem(bookName, salesPrice),
                            minQty_(qty), discount_(salesDisc) {}
 double BulkItem::netPrice(int cnt) const {
  return (cnt > minQty_ ? cnt * price_ * discount_ : cnt * price_);
}
 