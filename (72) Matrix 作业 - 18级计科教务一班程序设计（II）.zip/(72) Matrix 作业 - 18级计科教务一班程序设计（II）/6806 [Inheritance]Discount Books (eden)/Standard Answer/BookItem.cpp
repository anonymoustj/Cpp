#include "BookItem.h"
#include <iostream>
using std::string;
 BookItem::BookItem(const string& bookName,
        double salesPrice) : name_(bookName), price_(salesPrice) {}
 double BookItem::netPrice(int cnt) const {
  return price_ * cnt;
}
 string BookItem::getName() const {
  return name_;
}
 