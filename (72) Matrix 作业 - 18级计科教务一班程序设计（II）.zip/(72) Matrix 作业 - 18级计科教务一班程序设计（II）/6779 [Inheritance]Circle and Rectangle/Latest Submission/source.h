class Point{
private:
double x,y;
public:
Point();
Point(double xv,double yv);
Point(Point& pt);
double getx();
double gety();
};
class Rectangle:public Point{
	private:
		double lenth;
		double high;
	public:
		Rectangle();
		Rectangle(Rectangle& other);
		Rectangle(double x,double y,double lenth,double high);
		int position(Point &pt); 
};
class Circle:public Point{
	private:
		double r;
	public:
		Circle(){
			r = 0;
		}
		Circle(Circle& other):Point(other){
			r = other.r;
		}
		Circle(double xv,double yv,double r):Point(xv,yv){
			this->r = r;
		}
		int position(Point &pt){
			if( ((pt.getx()-this->getx())*(pt.getx()-this->getx())+(pt.gety()-this->gety())*(pt.gety()-this->gety())) == r*r)
				return 0;
			else if(((pt.getx()-this->getx())*(pt.getx()-this->getx())+(pt.gety()-this->gety())*(pt.gety()-this->gety())) < r*r){
				return -1; 
			}
			else return 1;
		}
};
Point::Point(){
	x = 0;
	y = 0;
}
Point::Point(double xv,double yv){
	x = xv;
	y = yv;
}
Point::Point(Point& pt){
	x = pt.x;
	y = pt.y;
}
double Point::getx(){
	return x;
}
double Point::gety(){
	return y;
}
Rectangle::Rectangle(){
	lenth = 0;
	high = 0;
}
Rectangle::Rectangle(Rectangle& other):Point(other){
	lenth = other.lenth;
	high = other.high;
}
Rectangle::Rectangle(double xv,double yv,double lenth,double high):Point(xv,yv){
	this->lenth = lenth;
	this->high = high;
}
int Rectangle::position(Point &pt){
	if( (pt.getx()>this->getx())&&(pt.getx()<(this->getx()+lenth))&&(pt.gety()>this->gety())&&(pt.gety()<(this->gety()+high)) ){
		return -1;
	}
	else if( (pt.getx() < this->getx())|| (pt.getx() > (this->getx() + lenth)) || (pt.gety() < this->gety())||(pt.gety() > (this->gety() + high))){
		return 1;
	}
	else return 0;
}
