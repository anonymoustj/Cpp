#include <vector>
#include <deque>
#include <iostream>       // elementAccessDemo  8.5.cpp
using namespace std;

int main() {
    int iarr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    deque<int> ideq(iarr, iarr+10);
    deque<int>::iterator iter;

    cout << "before delete:" << endl;
    for (iter = ideq.begin(); iter != ideq.end(); iter++) {
        cout << *iter << " ";
    }

    ideq.pop_front();
    ideq.pop_back();

    // ????????list????????
    cout << endl << "the first and last element are deleted:" << endl;
    for (iter = ideq.begin(); iter != ideq.end(); iter++) {
        cout << *iter << " ";
    }

    iter = ideq.begin();
    ideq.erase(ideq.erase(iter+1));

    // ????????list????????
    cout << endl << "the second and third element are deleted:" << endl;
    for (iter = ideq.begin(); iter != ideq.end(); iter++) {
        cout << *iter << " ";
    }

   ideq.erase(ideq.begin(),ideq.begin()+3);

    // ????????list????????
    cout << endl << "three elements at front are deleted:" << endl;
    for (iter = ideq.begin(); iter != ideq.end(); iter++) {
        cout << *iter << " ";
    }

    ideq.clear();

    cout << endl << "after clear:" << endl;
    if (ideq.empty())    // ????
        cout << "no element in double-ended queue" << endl;

    return 0;
}