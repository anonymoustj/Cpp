
#include <iostream>
#include <cstring>
#include<sstream>
#include"SimpleList.hpp"

list::list()
{
	head=new node;
	head->next=NULL;
	_size=0;
}
list::list(const list& list1)
{
	head=new node;
	head->next=NULL;
	_size=0;
	node *new_head=list1.head;
	int a[10000],i=0,num=list1._size;
	while(new_head->next!=NULL)
	{
		a[i++]=new_head->next->data;
		new_head=new_head->next;
	}
	while(num--)
	{
	    node *new_node=new node;
		head->data=a[num];
	    new_node->next=head;
	    head=new_node;
	}
	_size=list1._size;
}
list& list::operator=(const list& list1)
{
  if(head!=NULL)
    clear();
	head=new node;
	head->next=NULL;
	_size=0;
	node *new_head=list1.head;
	int a[10000],i=0,num=list1._size;
	while(new_head->next!=NULL)
	{
		a[i++]=new_head->next->data;
		new_head=new_head->next;
	}
	while(num--)
	{
	    node *new_node=new node;
		head->data=a[num];
	    new_node->next=head;
	    head=new_node;
	}
	_size=list1._size;
	return *this;
}
list::~list()
{
	node *new_node_to_delete=NULL;
	while(head!=NULL)
	{
		new_node_to_delete=head;
		head=head->next;
		delete new_node_to_delete;
		new_node_to_delete=NULL;
		_size--;
		
	}
}
bool list::empty(void) const
{
	if(_size==0)
	return true;
	else
	{
		return false;
	}
}
int list::size(void) const
{
	return _size;
}
std::string list::toString(void) const
{
	using namespace std;
	string _string,st;
	node *new_head=head;
	int num=size(),i=0,a[10000];
	while(new_head->next!=NULL)
	{
		a[i++]=new_head->next->data;
		new_head=new_head->next;
	}

while(num>0)
	{
	    stringstream ss;
		ss<<a[num-1];
		ss>>st;
		_string+=st;
		_string+="->";
		num--;
		if(num==0)
		{
			_string+="NULL";
		}
	}
	return _string;
}

void list::insert(int position, const int& data)
{
	if(position>_size)
	return;
	node *new_head,*new_node;
		new_head=head;
		int num=_size;
		while(num!=position)
		{
			new_head=new_head->next;
			num--; 
		}
		new_node=new node;
		new_node->data=data;
		if(position==0)
		{
			new_node->next=NULL;
		}
		else
		{
			new_node->next=new_head->next;
		}
		new_head->next=new_node;
		_size++;
}
void list::erase(int position)
{
	if(position>=_size)
	return;
	node *new_head=head,*p;
	int num=_size;
	while(num>position+1)
	{
		new_head=new_head->next;
		num--;
	}
	p=new_head->next;
	new_head->next=new_head->next->next;
	delete p;
	_size--;
}



list& list::sort(void)
{
	int ar[10000],i=0,size=_size,min_count,min,j=0;
	node *p;
	while(head->next!=NULL)
	{
		ar[i++]=head->next->data;
		p=head;
		head=head->next;
		delete p;
		_size--;
	}
	for(i=0;i<size;i++)
	{
		min=ar[i];
		min_count=i;
		for(j=i+1;j<size;j++)
		{
			if(ar[j]<min)
			{
				min=ar[j];
				min_count=j;
			}
		}
		ar[min_count]=ar[i];
		ar[i]=min;
	}
	for(i=0;i<size;i++)
	{
		insert(i,ar[i]);
	}
	return *this; 
}
