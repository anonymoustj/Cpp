#include<iostream>
using namespace std;

template <typename ElementType>                      
class Stack {
    public:
        Stack()
	{
		top=NULL;
	};
        ~Stack()
	{
		while(!isEmpty())
		{
			Node *t=top;
			top=top->next;
			delete t;
			t=NULL;
		}
	};
        void push(ElementType obj)      throw(std::bad_alloc)
        {
        	Node *new_node=new Node;
        	new_node->element=obj;
        	new_node->next=top;
        	top=new_node;
        };
        void pop()                      throw(std::logic_error)
        {
        	if(!isEmpty())
        	{
        		Node *t=top;
			top=top->next;
			delete t;
			t=NULL;
        	}
        };
        ElementType getTop() const      throw(std::logic_error)
        {
        	if(!isEmpty())
        	return top->element;
        };
        bool isEmpty() const
        {
        	if(top!=NULL)
        	return false;
        	else
        	{
        		return true;
        	}
        };
    private:
        struct Node { 
            ElementType element;     
            Node* next;             
        };
        Node* top;                  
};