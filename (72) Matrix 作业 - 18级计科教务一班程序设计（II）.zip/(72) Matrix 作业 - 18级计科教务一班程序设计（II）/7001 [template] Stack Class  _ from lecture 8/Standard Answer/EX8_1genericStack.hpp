#include <iostream>
#include <string>
#include <new>
#include <stdexcept>
using namespace std;

template <typename ElementType>                      
class Stack {
	public:
		Stack();
		~Stack();
		void push(ElementType obj)      throw(std::bad_alloc);
		void pop()                      throw(std::logic_error);
		ElementType getTop() const      throw(std::logic_error);
		bool isEmpty() const;
	private:
		struct Node { 
			ElementType element;     
			Node* next;	            
		};
		Node* top;		            
};


template <typename ElementType>
Stack<ElementType>::Stack()
{
     top = NULL;		
}

template <typename ElementType>
Stack<ElementType>::~Stack()
{
    Node* ptr;   

   while (top != NULL)   
   {			
        ptr = top;	             
        top = top->next;	
        delete ptr;		
    }
}

template <typename ElementType>
void Stack<ElementType>::push( ElementType obj ) throw(std::bad_alloc) {
	Node* temp;
	try {
		temp = new Node;
		temp -> element = obj;
		temp -> next = top;
		top = temp;
	} catch (std::bad_alloc e) { 
		throw;		
	}
}

template <typename ElementType>
void Stack<ElementType>::pop() throw(std::logic_error) {
	Node* temp;
	if (top != NULL) {
		temp = top;
		top = top -> next;
		delete temp;
	} else { 
		throw std::logic_error("pop from empty Stack");
	}
}

template <typename ElementType>
ElementType Stack<ElementType>::getTop() const throw(std::logic_error)  
{
    if (top != NULL)    
    {					
	return top->element;    
	} else { 
		throw std::logic_error("Get top from empty stack.");
	}
	
}

template <typename ElementType>
bool Stack<ElementType>::isEmpty() const  
{
     return (top == NULL);
}
