#include "AccountManager.hpp"

AccountManager::AccountManager() : accountNumber(0) {}

void AccountManager::open(string name) {
    if (accountNumber == 100)
        return;

    Account *account = new Account(name, 0);
    accountlist[accountNumber++] = *account;
    delete account;
}

void AccountManager::close(string name) {
    for (int i = 0; i < accountNumber; i++) {
        if (accountlist[i].getName() == name) {
            if (i != accountNumber-1) {
                accountlist[i] = accountlist[accountNumber-1];
            }
            accountNumber--;
            break;
        }
    }
}

void AccountManager::depositByName(string name, double num) {
    for (int i = 0; i < accountNumber; i++) {
        if (accountlist[i].getName() == name) {
            accountlist[i].deposit(num);
            break;
        }
    }
}

bool AccountManager::withdrawByName(string name, double num) {
    for (int i = 0; i < accountNumber; i++) {
        if (accountlist[i].getName() == name) {
            return accountlist[i].withdraw(num);
        }
    }
    return false;
}

double AccountManager::getBalanceByName(string name) {
    for (int i = 0; i < accountNumber; i++) {
        if (accountlist[i].getName() == name) {
            return accountlist[i].getBalance();
        }
    }
    return 0;
}

Account AccountManager::getAccountByName(string name) {
    for (int i = 0; i < accountNumber; i++) {
        if (accountlist[i].getName() == name) {
            return accountlist[i];
        }
    }
    return accountlist[99];
}