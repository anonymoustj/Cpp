#include <iostream>
#include <string>
#include "AccountManager.hpp"
#include "Account.hpp"

AccountManager::AccountManager(){
	int i;
	accountNumber = 0;
}
void AccountManager::open(string name_){
	Account temp(name_,0);
	accountlist[accountNumber++] = temp;
}
void AccountManager::close(string name_){
	int i;
	for(i = 0;i < accountNumber;i++){
		if(accountlist[i].getName() == name_){
			accountlist[i] = accountlist[accountNumber-1];
			break;
		}
	}
	accountNumber--;
}
void AccountManager::depositByName(string name_,double input){
	int i;
	for(i = 0;i < accountNumber;i++){
		if(accountlist[i].getName() == name_){
			accountlist[i].deposit(input);
			break;
		}
	}
}
bool AccountManager::withdrawByName(string name_,double output){
	int i;bool y;
	for(i = 0;i < accountNumber;i++){
		if(accountlist[i].getName() == name_){
			y = accountlist[i].withdraw(output);
			return y;
		}
	}
}
double AccountManager::getBalanceByName(string name_){
	int i;
	for(i = 0;i < accountNumber;i++){
		if(accountlist[i].getName() == name_){
			return accountlist[i].getBalance();
		}
	}
}
Account AccountManager::getAccountByName(string name_){
	int i;
	for(i = 0;i < accountNumber;i++){
		if(accountlist[i].getName() == name_){
			return accountlist[i];
		}
	}
}