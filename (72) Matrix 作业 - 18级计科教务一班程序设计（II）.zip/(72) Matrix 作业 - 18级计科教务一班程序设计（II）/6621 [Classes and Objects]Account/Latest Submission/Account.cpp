#include <iostream>
#include <string>
#include "Account.hpp"
using namespace std;

Account::Account(){
	this->name = '0';
	this->balance = 0;
}
Account::Account(string name_,double balance_){
	this->name = name_;
	this->balance = balance_;
}
void Account::deposit(double input){
	this->balance += input;
}
bool Account::withdraw(double output){
	if((this->balance - output) >= 0){
		this->balance -= output;
		return true;
	}
	return false;
}
string Account::getName(){
	return this->name;
}
double Account::getBalance(){
	return this->balance;
}