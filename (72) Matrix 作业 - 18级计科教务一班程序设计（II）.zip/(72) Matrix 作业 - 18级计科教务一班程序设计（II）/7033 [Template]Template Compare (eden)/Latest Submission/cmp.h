#include <iostream>
#include <string>
#include <cstring>
using namespace std;
template<typename T>
bool cmp(T& a,T& b){
	if(a >= b) return 1;
  return 0;
}
bool cmp(int *a,int *b){
  if(*a >= *b)return 1;
  return 0;
}
bool cmp(double *a,double *b){
  if(*a >= *b) return 1;
  return 0;
}
bool cmp(char* a,char* b){
 if(strcmp(a,b)>= 0) return 1;
  return 0;
}
bool cmp(string a,string b){
 if(a >= b) return 0;
  return 1;
}