# [Template]Template Compare (eden)

## Descrption
Haoran is a "huge god" who loves C++ so much.One day he wants to implement a
template function **cmp** which compares any type of two elements.Now he
passes the mission to you all and hopes you can implement it and makes it
suitable to compare any two **int**,** double, float, char*, string and any
two same type of pointers.**If the first parameter is  equal to the second
one, then return true, elsewise, false.



**You can be careful that:**


(1)When comparing two int, double, float, char*, string , you should compare their values.

(2)When comparing two pointers, you should compare the values they point to.

(3)the **cmp** function should always return a **boolean** value.

*出题人：劳思*
