#include<iostream>
#include"Bitset.h"
using namespace std;
bitset::bitset()
{
	for(int i=0;i<N;i++)
	{
		a[i]=0;
	}
}
void bitset::set(int pos)
{
    unsigned int num1=a[pos/32];
    unsigned int n=1;
	n<<=pos%32;
	if(num1&n)
	return;
	num1+=n;
	a[pos/32]=num1;
}
void bitset::reset(int pos)
{
	unsigned int num1=a[pos/32];
    unsigned int n=1;
	n<<=(pos%32);
	if(!(num1&n))
	return;
	num1-=n;
	a[pos/32]=num1;
}
int bitset::count() const
{
	int *bit_a,count=0;
	for(int i=0;i<max_length;i++)
	{
		if(test(i))
		count++;
	}
	return count;
}
bool bitset::test(int pos) const
{
	unsigned int num1=a[pos/32];
    unsigned int n=1;
	n<<=(pos%32);
	if(num1&n)
	return true;
	else
	return false;
}
bool bitset::any() const
{
	for(int i=0;i<N;i++)
	{
		if(a[i]!=0)
		{
			return true;
		}
	}
	return false;
}
bool bitset::none() const
{
	if(any())
	return false;
	else
	return true;
}
bool bitset::all() const
{
	for(int i=0;i<N;i++)
	{
		if(a[i]!=-1)
		{
			return false;
		}
	}
	return true;
}
bitset& bitset::operator&= (const bitset& b)
{
	for(int i=0;i<N;i++)
	{
		a[i]&=b.a[i];
	}
	return *this;
}
bitset& bitset::operator|= (const bitset& b)
{
	for(int i=0;i<N;i++)
	{
		a[i]|=b.a[i];
	}
	return *this;
}
bitset& bitset::operator^= (const bitset& b)
{
	for(int i=0;i<N;i++)
	{
		a[i]^=b.a[i];
	}
	return *this;
}
bitset& bitset::operator= (const bitset& b)
{
	for(int i=0;i<N;i++)
	{
		a[i]=b.a[i];
	}
	return *this;
}
bitset& bitset::operator >>= (int pos)
{
	int i=0,bit_c[max_length]={0},count=0;
	unsigned int temp=0,k=1;
	for(i=pos;i<max_length;i++)
	{
		if(test(i))
		{
			bit_c[count++]=1;
		}
		else
		bit_c[count++]=0;
	}
	if(test(159))
	while(count<max_length)
	{
		bit_c[count++]=1;
	}
	else
	while(count<max_length)
	{
		bit_c[count++]=0;
	}
	for(i=0;i<160;i++)
	{
		if(bit_c[i])
		set(i);
		else
		reset(i);
	}
	return *this;
}
bitset& bitset::operator <<= (int pos)
{
    int i=0,bit_c[max_length]={0},count=0;
    unsigned int temp=0,k=1;
    for(i=0;i<pos;i++)
    {
    	bit_c[count++]=0;
	}
	for(i=0;i<max_length-pos;i++)
	{
		if(test(i))
		{
			bit_c[count++]=1;
		}
		else
		bit_c[count++]=0;
	}
	for(i=0;i<160;i++)
	{
		if(bit_c[i])
		set(i);
		else
		reset(i);
	}
	return *this;
}
bitset bitset::operator~() const
{
	bitset new_bitset;
	for(int i=0;i<N;i++)
	{
		new_bitset.a[i]=~a[i];
	}
	return new_bitset;
}

bitset bitset::operator|(const bitset& b) const
{
	bitset new_bitset;
	for(int i=0;i<N;i++)
	{
		new_bitset.a[i]=a[i]|b.a[i];
	}
	return new_bitset;
}
bitset bitset::operator^(const bitset& b) const
{
	bitset new_bitset;
	for(int i=0;i<N;i++)
	{
		new_bitset.a[i]=a[i]^b.a[i];
	}
	return new_bitset;
}
bitset bitset::operator&(const bitset& b) const
{
	bitset new_bitset;
	for(int i=0;i<N;i++)
	{
		new_bitset.a[i]=a[i]&b.a[i];
	}
	return new_bitset;
}
bitset bitset::operator<<(int pos) const
{
	int i=0,bit_c[max_length]={0},count=0;
    unsigned int temp=0,k=1;
    bitset new_bitset;
    for(i=0;i<pos;i++)
    {
    	bit_c[count++]=0;
	}
	for(i=0;i<max_length-pos;i++)
	{
		if(test(i))
		{
			bit_c[count++]=1;
		}
		else
		bit_c[count++]=0;
	}
	for(i=0;i<160;i++)
	{
		if(bit_c[i])
		new_bitset.set(i);
		else
		new_bitset.reset(i);
	}
	return new_bitset;
}
bitset bitset::operator>>(int pos) const
{
	
	int i=0,bit_c[max_length]={0},count=0;
	unsigned int temp=0,k=1;
    bitset new_bitset;
	for(i=pos;i<max_length;i++)
	{
		if(test(i))
		{
			bit_c[count++]=1;
		}
		else
		bit_c[count++]=0;
	}
	if(test(159))
	while(count<max_length)
	{
		bit_c[count++]=1;
	}
	else
	while(count<max_length)
	{
		bit_c[count++]=0;
	}
	for(i=0;i<160;i++)
	{
		if(bit_c[i])
		new_bitset.set(i);
		else
		new_bitset.reset(i);
	}
	return new_bitset;
}
bool bitset::operator== (const bitset& b) const
{
	for(int i=0;i<N;i++)
	{
		if(a[i]!=b.a[i])
		{
			return false;
		}
	}
	return true;
}
bool bitset::operator!= (const bitset& b) const
{
	for(int i=0;i<N;i++)
	{
		if(a[i]!=b.a[i])
		{
			return true;
		}
	}
	return false;
}
bool bitset::operator[] (int pos) const
{
	unsigned int num1=a[pos/32];
    unsigned int n=1;
	n<<=(pos%32);
	if(num1&n)
	return true;
	else
	return false;
}
