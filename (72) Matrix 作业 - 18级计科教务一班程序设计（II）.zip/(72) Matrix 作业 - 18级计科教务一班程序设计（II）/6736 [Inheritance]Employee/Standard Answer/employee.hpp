#ifndef __EMPLOYEE_H__
#define __EMPLOYEE_H__

#include <string>
using std::string;

class Employee {
public:
    void setName(const string& name);
    string getName();
    virtual double getIncome()=0;
    virtual ~Employee() {}
protected:
    string name;
};

class Technician : public Employee {
public:
    void setHour(int hour);
    void setHourWage(double hourWage);
    double getIncome();
    virtual ~Technician() {}
protected:
    int hour;
    double hourWage;
};

class Salesman : public Employee {
public:
    void setSalesVolume(double salesVolume);
    void setProportion(double proportion);
    double getIncome();
    virtual ~Salesman() {};
protected :
    double salesVolume;
    double proportion;
};

class Manager : public Employee {
public:
    void setMonthlySalary(int monthlySalary);
    double getIncome();
protected:
    int monthlySalary;
};

class Salesmanager : public Salesman, public Manager {
public:
    double getIncome();
};

#endif
