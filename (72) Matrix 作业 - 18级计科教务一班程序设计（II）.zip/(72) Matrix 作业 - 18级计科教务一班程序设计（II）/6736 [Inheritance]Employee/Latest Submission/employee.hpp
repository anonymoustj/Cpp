#include<iostream>
#include<string>
using namespace std;
class Employee
{
	public:
		void setName(const string& name);
	    string getName();
	    virtual double getIncome()
	    {
		return 0;};
	 ~Employee(){};
 	private:
	 	string name;
	 	
};
class Technician:public Employee
{
	public:
		void setHour(int hour);
		void setHourWage(double hourWage);
		virtual double getIncome();
		 ~Technician(){};
	protected:
		int hour;
		double hourWage;
};

class Salesman:public Employee
{
	public:
		void setSalesVolume(double salesVolume);
		void setProportion(double proportion);
		virtual double getIncome();
		 ~Salesman(){};
	protected:
		double salesVolume;
		double proportion;
};

class Manager:public Employee
{
	public:
		void setMonthlySalary(int monthlySalary);
		virtual double getIncome();
		 ~Manager(){};
	protected:
		int monthlySalary;
};
class  Salesmanager:public Manager,public Salesman
{
	public:
		virtual double getIncome();
	 ~Salesmanager(){};
		
};