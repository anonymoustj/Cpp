#include <iostream>
#include "f.hpp"
using namespace std;

int main()
{
    for (int i = 1; i < 4; i++)
        f1(i);

    cout << "End of main" << endl;

    return 0;
}