void f1(int x);
void f2(int x);