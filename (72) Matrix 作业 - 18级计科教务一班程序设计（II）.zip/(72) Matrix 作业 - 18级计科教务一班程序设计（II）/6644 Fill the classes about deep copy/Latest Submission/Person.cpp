#include"Person.h"
Date::Date(int y, int m, int d) { year=y; month=m; day=d; }
int Date::getYear() { return year; }
void Date::setYear(int y) { year = y; }
int Date::getMonth() { return month; }
void Date::setMonth(int y) { month = y; }
int Date::getDay() { return day; }
void Date::setDay(int y) { day = y; }
Person::Person(Person & a)
{
  id=a.id;
  birthDate=new Date(a.birthDate->getYear(),a.birthDate->getMonth(),a.birthDate->getDay());
  
}
Person::Person(int id, int year, int month, int day) {

        this->id = id;
 
        birthDate = new Date(year, month, day);

    }

Person::~Person() { delete birthDate; }

int Person::getId() { return id; }

Date* Person::getBirthDate() { return birthDate; }