#include <stdio.h>
#include <assert.h>
typedef struct {
  int year, month, day;
} Date;

Date* CreateDate(int year, int month, int day);
void DestroyDate(Date** p);
Date* CopyDate(const Date* date);

int GetYear(const Date* date);
int GetMonth(const Date* date);
int GetDay(const Date* date);
void SetYear(Date* date, int year);
void SetMonth(Date* date, int month);
void SetDay(Date* date, int day);
void SetDate(Date* date, int year, int month, int day);

char* GetDateString(const Date* date);
void DestroyDateString(char** p);

void IncreaseDate(Date* date);
void DecreaseDate(Date* date);
int daysOfMonth(int , int );



Date* CreateDate(int year, int month, int day){
  Date *p;
  p=(Date *)malloc(sizeof(Date));
  p->day=day;
  p->month=month;
  p->year=year;
  return p;
}
void DestroyDate(Date** p){
  free(*p);
  *p=NULL;
}
Date* CopyDate(const Date* date){
  Date *p1;
  p1=(Date *)malloc(sizeof(Date));
  p1->day=date->day;
  p1->month=date->month;
  p1->year=date->year;
  return p1;
}

int GetYear(const Date* date){
  return date->year;
}
int GetMonth(const Date* date){
  return date->month;
}
int GetDay(const Date* date){
  return date->day;
}
void SetYear(Date* date, int year){
}
void SetMonth(Date* date, int month){
}
void SetDay(Date* date, int day){
}
void SetDate(Date* date, int year, int month, int day){
}
char* GetDateString(const Date* date){
  static char str[11];
  snprintf(str,11, "%04d-%02d-%02d",date->year,date->month,date->day );
	return str;
}
void DestroyDateString(char** p){


*p=NULL;
   free(*p);
  *p=NULL;
}

void IncreaseDate(Date* date){
date->day++;
   if(date->day>daysOfMonth(date->year,date->month)){
    date->day=1;
    date->month++;
    if(date->month>12){
      date->month=1;
      date->year++;
    }
  }
}
void DecreaseDate(Date* date){
date->day--;
    if(date->day==0){
    if(date->month==1){
      date->day=31;
      date->month=12;
      date->year--;
    }
    else{
      date->month--;
      date->day=daysOfMonth(date->year,date->month);
    }
  }
}
int daysOfMonth(int year, int month) {
switch (month){
      case 4:case 6:case 9:case 11:
      return 30;
    case 2:
      if((year%4==0&&year%100!=0)||year%400==0)
        return 29;
      else
        return 28;
      default:
      return 31;
}
}