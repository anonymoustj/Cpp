# Hello World

C++入门程序：请大家写一个C++程序来输出“Hello World”。

##### 输入
```
无
```

##### 输出
```
Hello World
```