#include<iostream>
#include<queue>
#include<utility>
using namespace std;

int main(){
	int num;
	cin >> num;
	while(num--){
		int time = 0;
		int n,m;
		cin >> n >> m;
		priority_queue<int> q;
		queue< pair<int,int> > p;
		for(int i = 0;i < n;i++){
			int temp;
			cin >> temp;
			q.push(temp);
			pair<int,int> tp(temp,i);
			p.push(tp);
		}
		pair<int,int> p2;
		 while(1){
            p2 = p.front();p.pop();
            if(p2.first == q.top()) {
                time++;
                q.pop();
                if(p2.second == m) break;
            }
            else p.push(p2);
        }
        cout << time << endl;
	}
}