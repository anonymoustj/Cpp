#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	int l=0;
	string str;
	cin>>l;
	while(l--)
	{
		cin>>str;
		int len=str.length(),begin=0,end=0;
		for(int i=0;i<len;i++)
		{
			if(str[i]=='_'||i==len-1)
			{
				if(i==len-1&&str[i]!='_')
				end=i;
				else
				end=i-1;
				for(int j=end;j>=begin;j--)
				{
					cout<<str[j];
				}
				begin=i+1;
				if(begin!=len)
				{
					cout<<"_";
				}
				else if(begin==len&&str[i]=='_')
				{
					cout<<"_"<<endl;
				}
				else
				{
					cout<<endl;
				}
				
			}
		}
	}
}