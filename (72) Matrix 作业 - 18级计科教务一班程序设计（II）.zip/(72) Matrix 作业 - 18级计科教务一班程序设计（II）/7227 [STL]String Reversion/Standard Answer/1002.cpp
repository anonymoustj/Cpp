// Problem#: 17856
// Submission#: 4638416
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include <iostream>
#include <string>
#include <cstdio>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        string s;
        cin >> s;
        s = "_" + s + "_";
        int bPos = s.find("_");
        int ePos = s.length();
        while (1) {
            if (bPos != string::npos) {
                int pos = s.find("_", bPos+1);
                if (pos != string::npos) {
                    ePos = pos;
                } else {
                    ePos = s.length();
                }
            }
            reverse(s.begin()+bPos+1, s.begin()+ePos);
            bPos = ePos;
            if (bPos == s.length()) break;
        }
        cout << s.substr(1, s.length()-2) << endl;
    }
    return 0;
}                                 

