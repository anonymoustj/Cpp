#include <iostream>
#include <map>
#include <utility>
using namespace std;
int main() {
    map <char, int>m;
    int i;

    for(i = 0;i < 26;i++){
    	char a = 'A';
    	int aa =  'A';
    	m.insert(pair<char,int>(a,aa));
    	a++;
    	aa++;
	}

    char ch;
    cout <<"enter key:";
    cin >>ch;
    map<char, int>::iterator p;

    map<char, int>::iterator it;
    it = m.find(ch);
    p = it;
	

    if (p!=m.end())
        cout <<"Its ASCII value is " <<p->second;
    else
        cout <<"Key not in map." ;
    return 0;
}