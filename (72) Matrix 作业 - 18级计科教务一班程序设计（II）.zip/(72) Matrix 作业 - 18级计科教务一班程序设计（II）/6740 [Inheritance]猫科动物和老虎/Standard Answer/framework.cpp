#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
using namespace std;
#include "source.h"


int main()
{
 Tiger t1(9);
 Cat c1;
 Tiger t2(25);

 return 0;
}
