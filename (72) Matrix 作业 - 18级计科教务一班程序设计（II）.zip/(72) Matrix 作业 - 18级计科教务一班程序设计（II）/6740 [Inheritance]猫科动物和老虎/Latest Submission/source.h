#include<iostream>
using namespace std;

class Cat
{
    int data;
public:
    Cat();
    Cat(int num);
    ~Cat();
    
};

class Tiger:public Cat
{
    int data;
public:
    Tiger(int num):Cat(num)
{
	data=num;
	cout<<"Constructor of Tiger is Running "<<num<<endl;
};
    ~Tiger();
};

Cat::Cat()
{
	data=0;
	cout<<"Default Constructor of Cat is Running"<<endl;
}
Cat::Cat(int num)
{
	data=num;
	cout<<"Constructor of Cat is Running "<<num<<endl;
}
Cat::~Cat()
{
	cout<<"Destructor of Cat is Running "<<data<<endl;
}

Tiger::~Tiger()
{
	cout<<"Destructor of Tiger is Running "<<data<<endl;
	
}