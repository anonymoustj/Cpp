#include "userController.hpp"
#include <iostream>
#include <sstream>
#include <ctype.h>
#include <cstring>
using namespace std;
using namespace Alipay;
bool verifyPassword(const char* password) {
	int n=strlen(password);
	if(n<8||n>20)
	return false;
	for(int i=0;i<n;i++)
	    if(!isalnum(password[i]))
	    return false;
	return true;
}
bool verifyUsername(const char* username) {
	int n=strlen(username);
	if(n<6||n>20)
	return false;
	for(int i=0;i<n;i++)
	    if(!isalnum(username[i]))
	    return false;
	return true;
}
userController::userController(double interest_rate) {
	this->interest_rate=interest_rate;
	usercount=0;
}
userController::~userController() {
	for(int i=0;i<usercount;i++) {
		delete users[i];
		users[i]=NULL;
	}
	usercount=0;
}
int userController::getUserIndex(const char* username) const {
    for(int i=0;i<usercount;i++)
        if(!strcmp(users[i]->getUsername(),username))
        return i;
    return -1;
}
bool userController::createUser(const char* username, const char* password) {
	if(!verifyUsername(username)||!verifyPassword(password))
	return false;
	users[usercount++]=new user(username,password);
	return true;
}
bool userController::deposite(const char* username, double amount) {
	int n=getUserIndex(username);
	if(n==-1)
	return false;
	return users[n]->deposite(amount);
}
bool userController::withdraw(const char* username, double amount) {
	int n=getUserIndex(username);
	if(n==-1)
	return false;
	return users[n]->withdraw(amount);
}
std::string userController::getUserInfoByName(const char* username) const {
	int n=getUserIndex(username);
	string str;
	if(n==-1) {
		str="No such user!";
		return str;
	}
	string _username = users[n]->getUsername();
  string _balance;
  stringstream ss;
  ss << users[n]->getBalance();
  ss >> _balance;
  str = "username:" + _username + "\npassword:*********\n" + "balance:" + _balance;
	return str;
}
int userController::getUserCount(void) const {
	return usercount;
}
bool userController::removeUserByUsername(const char* username) {
	int n=getUserIndex(username);
	if(n==-1)
	return false;
	delete users[n];
	users[n]=users[usercount-1];
	users[--usercount]=NULL;
	return true;
}
bool userController::setInterest(double interest) {
	if(interest<0)
	return false;
	interest_rate=interest;
	return true;
}
void userController::payInterest(void) {
	for(int i=0;i<usercount;i++)
	users[i]->deposite(users[i]->getBalance()*interest_rate);
}