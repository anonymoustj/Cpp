// Problem#: 17976
// Submission#: 4698440
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include<iostream>
using namespace std;
class Int {
  int data;
 public:
  static int num;
  static bool isodd(int m) {
   if(m%2!=0) return true;
   else
    return false;
  };
  Int() {
   data=0;
   ++num;
   cout << num <<" objects of Int has been constructed." <<endl;
  }
  Int(int m) {
   ++num;
   data=m;
   cout << num <<" objects of Int has been constructed." <<endl;
  }
  ~Int() {
   --num;
  };
};