#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

class Int
{
	private:
int data;
static int num;
public:
  ~Int()
  {
    num--;
  }
Int(int n=0){
	cout<<++num<<" objects of Int has been constructed.\n";
	data=n;
}; //将n的值赋给data
static int isodd(int n){
	return n%2;
};

};