#ifndef SOURCE_H
#define SOURCE_H
#include <cstring>
#include <cstdio>
#include <string>
#include<stdexcept>
using namespace std;

int parseHex(const char*const hexString){
	int len = strlen(hexString);
	int power = 1;
	int sum = 0;
	for(int i = len-1;i >= 0;i--){
		if(hexString[i] > 'F') 
			throw runtime_error ("Hex number format error");
		else{
			if(isdigit(hexString[i])) sum = sum + power*(hexString[i] - '0');
			else{
				int temp = hexString[i] - 55;
				sum = power*temp + sum;
			}
		}
		power *= 16;
	}
	return sum;
}
#endif