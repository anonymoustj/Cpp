#include<iostream>
#include<cstring>
int main()
{
using namespace std;
char str1[100],str2[100],str3[100];
int num;
cin>>num;
for(int i=0;i<num;i++)
{
cin>>str1;
cin>>str2;
strcat(str1,str2);
for(int j=strlen(str1)-1;j>=0;j--)
{
cout<<str1[j];
}

cout<<endl;
}
return 0;
}
