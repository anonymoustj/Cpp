# 字符串反向拼接

给定两个字符串，把它们拼接到一起以后反向输出出来。比如“ab”和"cd"，拼接成"abcd"后按照"dcba"输出。字符串没有空格且长度小于等于40。
输入的第一行为测试样例个数，接下来的每两行代表一个样例，分别是第一个字符串和第二个字符串。输入为拼接后的反向输出。
#### 输入
```
2
abcdefg
hijklmn
i_love_you
uoy_evol_i
```
#### 输出
```
nmlkjihgfedcba
i_love_youuoy_evol_i
```