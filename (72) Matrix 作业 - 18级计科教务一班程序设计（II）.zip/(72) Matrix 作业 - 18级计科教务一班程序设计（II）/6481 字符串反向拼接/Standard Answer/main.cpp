#include <iostream>
using namespace std;


int main(void){
	string first, second;
	int t;
	cin >> t;
	while(t--){
		cin >> first;
		cin >> second;
		
		int len = second.length();
		while(len--){
			cout << second[len];
		}
		len = first.length();
		while(len--){
			cout << first[len];
		}
		cout << endl;
	}
} 

