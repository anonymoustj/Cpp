#include<string.h>
#include<iostream>
using namespace std;
class Object
{
	public:
		Object()
		{
			name="Object";
		}
		Object(string name_)
		{
			name=name_;
		}
		virtual ~Object() {}
	virtual string getName() { return name;}
	private:string name;
};
class Animal: public Object
{
	private:string name;
		public:
			Animal() {name="Animal";}
			virtual ~Animal() {}
			virtual string getName() { return name;}
};
class Dog: public Animal
{
	private:string name;
		public:
			Dog() { name="Dog"; }
			virtual ~Dog() {}
			virtual string getName() { return name;}
};
class Cat: public Animal
{
	private:string name;
		public:
			Cat() { name="Cat";}
			virtual ~Cat() {}
			virtual string getName() { return name;}
};
class Vehicle: public Object
{
	private:string name;
		public:
			Vehicle() { name="Vehicle";}
			virtual ~Vehicle() {}
			virtual string getName() { return name;}
};
class Bus: public Vehicle
{
	private:string name;
		public:
			Bus() { name="Bus"; }
			virtual ~Bus() {}
			virtual string getName() { return name;}
};
class Car: public Vehicle
{
	private:string name;
		public:
			Car() { name="Car";}
			virtual ~Car() {}
			virtual string getName() { return name;}
};

/*
 * 返回这个对象实例实际的类型名
 * 例如: Object *obj = new Bus();
 * 则 instaceOf(obj) == "Bus"
 * 若 obj == NULL
 * 则 instanceOf(obj) == "NULL"
 */
string instanceOf(Object *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}
string instanceOf(Animal *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}
string instanceOf(Vehicle *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}
string instanceOf(Car *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}
string instanceOf(Dog *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}
string instanceOf(Bus *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}
string instanceOf(Cat *obj)
{
	string a;
	if(obj==NULL)
	{
		a="NULL";
		return a;
	}
	else
	return obj->getName();
}