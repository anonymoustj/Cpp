#include <string>
#include <iostream>
 
using namespace std;
 
class Object {
 public:
    virtual string getInstance() { return "Object"; }
};
 
class Animal: public Object {
 public:
    string getInstance() { return "Animal"; }
};
 
class Dog: public Animal {
 public:
    string getInstance() { return "Dog"; }
};
 
class Cat: public Animal {
 public:
    string getInstance() { return "Cat"; }
};
 
class Vehicle: public Object {
 public:
    string getInstance() { return "Vehicle"; }
};
 
class Bus: public Vehicle {
 public:
    string getInstance() { return "Bus"; }
};
 
class Car: public Vehicle {
 public:
    string getInstance() { return "Car"; }
};
 
string instanceOf(Object *obj) {
    if (obj == NULL) {
        return "NULL";
    }
    return obj->getInstance();
}
 