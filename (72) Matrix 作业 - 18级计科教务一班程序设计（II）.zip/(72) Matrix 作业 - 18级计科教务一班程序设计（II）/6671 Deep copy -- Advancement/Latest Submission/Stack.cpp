#include<iostream>
#include"Stack.hpp"
using namespace std;
Stack::Stack()                 // 构造一个空栈
{
	p.data=new node;
	p.data->next=NULL;
	p.count=new int;
	(*p.count)=1;
}
Stack::Stack(const Stack& s)           // 写时复制规则
{
    p.count=s.p.count;
	(*p.count)++;
	p.data=s.p.data;
}
Stack::~Stack()                       // 注意内存回收
{
	if(p.count!=NULL)
	clear();
}
Stack Stack::operator=(const Stack& s)  // 写时复制规则
{
	if(this!=&s)
	{
		if(!empty())
		{
			clear();
		}
		else
		{
			delete p.count;
			delete p.data;
		}
		p.count=s.p.count;
		(*p.count)++;
		p.data=s.p.data;
	}
	return *this;
}
void Stack::push(int num)                 // 入栈
{
	if((*p.count)>1)
	{
		copyOnWrite();
	}
	node *new_node=new node;
	p.data->num=num;
	new_node->next=p.data;
	p.data=new_node;
}
void Stack::pop()                    // 出栈
{
	if((*p.count)>1)
	{
		this->copyOnWrite();
	}
	else
	{	if(empty())
		return ;
		struct node *new_p=p.data;
		p.data=p.data->next;
		delete new_p;
	}
}
int Stack::top() const              // 查看栈顶元素
{
	if(!empty())
	return p.data->next->num;
}
bool Stack::empty() const            // 判断栈是否为空
{
	if(p.data!=NULL&&p.data->next!=NULL)
	{
		return false;
	}
	else
	{
		return true;
	}
}
void Stack::clear()
{
	if(*(p.count)<2)
	{
		node *new_node=NULL;
		while(!empty())
		{
			new_node=p.data;
			p.data=p.data->next;
			delete new_node;
		}
    delete p.data;
		delete p.count;
	}
	else
	{
		p.data=NULL;
		(*p.count)--;
		p.count=NULL;
	}
}
void Stack::copyOnWrite()
{
	Stack *new_stack;
	struct node *new_node=this->p.data;
	int a[100]={0},i=0;
	new_stack->p.data=new node();
	new_stack->p.count=new int;
	*(new_stack->p.count)=*(p.count);
	while(new_node->next!=NULL)
	{
		a[i++]=new_node->next->num;
		new_node=new_node->next;
	}
	if(i==0)
	{
		new_stack->p.data->next=NULL;
		(*new_stack->p.count)=1;
	}
	while(i>0)
	{
		i--;
		new_stack->p.data->num=a[i];
		struct node *new_ptr=new node;
		new_ptr->num=0;
		new_ptr->next=p.data;
		p.data=new_ptr;
	}
	(*new_stack->p.count)=1;
	(*(this->p.count))--;
	*this=*new_stack;
}