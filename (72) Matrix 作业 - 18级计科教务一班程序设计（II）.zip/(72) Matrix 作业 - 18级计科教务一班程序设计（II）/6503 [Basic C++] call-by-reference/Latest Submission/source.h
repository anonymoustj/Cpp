
#include<iostream>
using namespace std;
void addxy(int x,int y,int total);
void subxy(int x,int y,int &total);

void subxy(int x,int y,int &total)
{
	total=x-y;
cout<<"Total from inside subxy: "<<x-y<<endl;
}

void addxy(int x,int y,int total)
{
         cout<<"Total from inside addxy: "<<x+y<<endl;

}