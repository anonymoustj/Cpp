#include "SingleDog.h"
#include <cstring>

SingleDog::SingleDog(int id_, char* name_) : id(id_) {
    name = new char[strlen(name_)+1];
    strcpy(name, name_);
    count++;
}

SingleDog::SingleDog(const SingleDog &other) : id(other.id) {
    name = new char[strlen(other.name)+1];
    strcpy(name, other.name);
    count++;
}

SingleDog::~SingleDog() {
    delete []name;
    name = NULL;
    count--;
}

int SingleDog::getCount() {
    return count;
}

int SingleDog::count = 0;