#include<iostream>
#include"Vector.h"
using namespace std;
Vector::Vector(string a, int b, int *c)
{
	name=a;
	dimension=b;
	param=c;
 cout<<"construct a vector called "<<name<<".\n";
}
Vector::Vector(const Vector &otherVec)
{
	
	name=otherVec.name;
	dimension=otherVec.dimension;
	param=otherVec.param;
	cout<<"copy a vector called "<<name<<".\n";
}
Vector::~Vector()
{
	cout<<"release memory from a vector called "<<name<<".\n";
}
void Vector::isEqual(const Vector & c)
{
	if(c.name==name)
	{
		if(c.param==param)
		{
			cout<<"same name, same value.\n";
		}
		else
		cout<<"same name, different value.\n";
	}
	else
	{
		if(c.param==param)
		{
			cout<<"different name, same value.\n";
		}
		else
		cout<<"different name, different value.\n";
	}
}
void Vector::setName(string a)
{
	name=a;
}
void Vector::print()
{
	cout<<name<<"(";
	for(int i=0;i<dimension-1;i++)
	{
		cout<<param[i]<<", ";
	}
	cout<<param[dimension-1]<<")\n";
}