# [Excpetion] Calculate the Triangle Area _ from lecture 9

## Description
你需要实现area函数来计算三角形面积，如果三边不为正，则抛出异常信息为"the side length should be positive"的invalid_argument异常；若三边不满足三角不等式，则抛出异常信息为"the side length should fit the triangle inequation"的invalid_argument异常。