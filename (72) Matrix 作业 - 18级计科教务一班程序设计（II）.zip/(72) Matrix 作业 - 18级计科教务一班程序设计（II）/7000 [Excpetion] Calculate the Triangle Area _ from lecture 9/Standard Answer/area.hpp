#ifndef AREA
#define AREA

#include <stdexcept>
using namespace std;

double area(double a, double b, double c)  throw (invalid_argument);


#endif