#include<iostream>
#include<string.h>
#include<cstring>
#include <fstream>
using namespace std;

class base
{
char *name;
int age;
public:
base()
{
	name=NULL;
	age=0;
};
void setname(char arr[])
{
	int len=strlen(arr);
	name=new char[len];
	for(int i=0;i<len;i++)
	{
		name[i]=arr[i];
	}
};
void setage(int age)
{
	this->age=age;
};
char* getname()
{
	return this->name;
};
int getage()
{
	return this->age;
};
};

class leader:virtual public base
{
	private:
		char *job;
		char *dep;
	public:
		void setjob(char arr[])
		{
			int len=strlen(arr);
			job=new char[len];
			for(int i=0;i<len;i++)
			{
				job[i]=arr[i];
			}
		};
		void setdep(char arr[])
		{
			int len=strlen(arr);
			dep=new char[len];
			for(int i=0;i<len;i++)
			{
				dep[i]=arr[i];
			}
		};
		char* getjob()
		{
			return this->job;
		};
		char* getdep()
		{
			return this->dep;
		};
		
		
};
class engineer:virtual public base
{
	private:
		char *prof;
		char *major;
	public:
		void setprof(char arr[])
		{
			int len=strlen(arr);
			this->prof=new char[len];
			for(int i=0;i<len;i++)
			{
				this->prof[i]=arr[i];
			}
		};
		void setmajor(char arr[])
		{
			int len=strlen(arr);
			this->major=new char[len];
			for(int i=0;i<len;i++)
			{
				this->major[i]=arr[i];
			}
		};
		char* getmajor()
		{
			return this->major;
		};
		char* getprof()
		{
			return this->prof;
		};	
};

class chairman:virtual public leader,virtual public engineer
{
	
};
