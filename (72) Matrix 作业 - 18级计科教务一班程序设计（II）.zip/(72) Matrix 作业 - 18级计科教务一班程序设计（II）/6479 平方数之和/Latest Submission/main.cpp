#include<iostream>
int main()
{
using namespace std;
int num,sum;
cin>>num;
for(int i=1;i<100;i++)
{
sum=0;
for(int j=1;j<100;j++)
{
sum=i*i+j*j;
if(sum==num){
cout<<"true"<<endl;
return 0;
}
}
}
cout<<"false\n";
}