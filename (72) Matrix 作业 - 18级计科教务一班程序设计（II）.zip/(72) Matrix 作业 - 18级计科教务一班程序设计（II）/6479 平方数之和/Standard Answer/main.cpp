#include<iostream>
#include<cmath>
using namespace std;
int main(void){
	int num, i, flag;
	cin >> num;
	flag = 0;
	for(i = 0; i <= sqrt(num/2); i++){
		int t;
		t = sqrt(num - i * i);
		if(t * t == num - i * i){
			flag = 1;
			break;
		}
	}
	if(flag){
		cout << "true" << endl;
	}else{
		cout << "false" << endl;
	}
} 

