#include<iostream>
using namespace std;
int main(void)
{
	int r=0;
  int c=0;
  int **num;
	cin>>r>>c;
	
  num=new int*[r];
  
		for(int i=0;i<r;i++)
		{
			num[i]=new int[c];
		}
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			cin>>num[i][j];
		}
	}
	for(int i=0;i<r;i++)
	{
		int j=0;
		for(j=0;j<c-1;j++)
		{
			cout<<num[i][j]<<" ";
		}
		cout<<num[i][j]<<endl;
	}
	for(int i=0;i<r;i++)
	{
		delete[] num[i];
	}
	delete[] num;
}