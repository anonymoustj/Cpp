// #define STL_VERSION

#ifdef STL_VERSION

#include <iostream>
#include <string>
#include <list>
#include <utility>
#include <algorithm>

using std::cout;
using std::cin;
using std::string;
using std::list;
// using std::pair;
using std::find;
using std::endl;

// used to store <id, msg>, like key-value pair
struct mypair {
  int id;
  string msg;

  mypair(int id, string msg) : id(id), msg(msg) {}

  bool operator==(const mypair &other) {
    return this->id == other.id;
  }
};

int main() {
  int N = 0;
  cin >> N;
  
  list<mypair> messages;

  for (int i = 0; i < N; ++i) {
    int id;
    string msg;
    cin >> id >> msg;
    // generate a new pair
    mypair p = mypair(id, msg);

    list<mypair>::iterator iter = find(messages.begin(), messages.end(), p);

    // if there is already a message box, erase it first
    if (iter != messages.end()) {
      messages.erase(iter);
    }

    // regardless of whether there was a message box, insert to the first position
    messages.insert(messages.begin(), p);
  }

  for (list<mypair>::iterator iter = messages.begin(); iter != messages.end(); ++iter) {
    cout << iter->id << ":\t" << iter->msg << endl;
  }

  return 0;
}

#else

#include <iostream>
#include <string>
#include <cstring>

using std::cout;
using std::cin;
using std::string;
using std::endl;

int findInIds(int ids[], int len, int id) {
  for (int i = 0; i < len; ++i) {
    if (ids[i] == id) {
      return i;
    }
  }
  return -1;
}

int main() {
  int N = 0;
  cin >> N;
  int ids[50] = {};
  string strs[50];
  memset(ids, 0, sizeof(ids));

  int len = 0;

  for (int i = 0; i < N; ++i) {
    int x = 0;
    string s;
    cin >> x >> s;
    int index = findInIds(ids, len, x);
    if (index >= 0) {
      // if found, delete(actually, overwrite) the element, and move elements
      for (int i = index; i > 0; --i) {
        ids[i] = ids[i - 1];
        strs[i] = strs[i - 1];
      }
    } else {
      // if not, move all the elements
      for (int i = len; i > 0; --i) {
        ids[i] = ids[i - 1];
        strs[i] = strs[i - 1];
      }
      ++len;
    }
    ids[0] = x;
    strs[0] = s;
  }

  for (int i = 0; i < len; ++i) {
    cout << ids[i] << ":\t" << strs[i] << endl;
  }

  return 0;
}

#endif