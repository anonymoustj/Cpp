#include<iostream>
#include<string>
#include<map>
#include<list>
#include<algorithm>
using namespace std;

int main()
{
	list<pair<string,string> > a;
	list<pair<string,string> >::iterator iter,iter2,iter3;
	int N;
	cin>>N;
	while(N--)
	{
		iter=a.begin();
		int flag=0;
		string a1,b,a2,b2;
		cin>>a1>>b;
		for(;iter!=a.end();iter++)
		{
			if(iter->first==a1)
			{
				flag=1;
				iter->first="false";
				break;
			}
		}
		a.push_back(pair<string ,string>(a1,b));
	}
	iter=a.end();
	while(iter!=a.begin())
	{
		iter--;
		if(iter->first!="false")
		cout<<iter->first<<":\t"<<iter->second<<endl;
	}
	return 0;
}