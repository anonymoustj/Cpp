#include "Figure.h"
using namespace std;

class TRIANGLE: public FIGURE
{
    public:

double get_area()
{
    return  (x_size*y_size)/2;
};
};
