#include"Figure.h"
#include <iostream>

void FIGURE:: set_size (double x, double y)
{
    x_size=x;
    y_size=y;
};

