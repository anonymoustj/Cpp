
#include "Figure.h"
using namespace std;

class RECTANGLE : public FIGURE
{
public:
    double get_area()
    {
        return x_size*y_size;
    };
};