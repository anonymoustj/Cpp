#include "Figure.h"
using namespace std;

class CIRCLE : public FIGURE
{
public:
    double get_area()
    {
        return x_size * x_size * PI;
    };
};