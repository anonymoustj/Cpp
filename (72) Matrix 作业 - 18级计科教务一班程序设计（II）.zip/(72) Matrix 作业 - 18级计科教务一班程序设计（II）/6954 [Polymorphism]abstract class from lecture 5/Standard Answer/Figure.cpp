#include "Figure.h"

void FIGURE::set_size(double x, double y)
{
	x_size = x;
	y_size = y;
}
