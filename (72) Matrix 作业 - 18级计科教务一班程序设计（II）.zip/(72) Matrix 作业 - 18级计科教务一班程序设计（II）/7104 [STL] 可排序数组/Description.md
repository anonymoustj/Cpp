# [STL] 可排序数组

# 可排序数组

# Description
<p>可排序数组 SortableArray定义如下：</p>
<p>1. 可通过成员函数pushBack插入一个元素</p>
<p>2.可通过成员函数sort对数组进行升序排序</p>
<p>3.可通过成员函printArray数输出数组</p>
<p>4.可排序数组SortableArray是一个模板类</p>
<p>5.SortableArray的实例：SortableArray&lt;int&gt; array( maxArraySize ) ;</p>
<p>（请实现SortableArray，注意在提交的代码中请不要包含 main()函数 ）</p>

# Input
<p>测试框架如下：</p>
<p>int maxSize = 10 ;</p>
<p>SortableArray&lt; int &gt; arr( maxSize ) ;</p>
<p>arr.pushBack( 45 )&nbsp;;</p>
<p>arr.pushBack( 32 )&nbsp;;</p>
<p>arr.pushBack( 41 )&nbsp;;</p>
<p>arr.printArray()&nbsp;;</p>
<p>arr.sort() ;</p>
<p>arr.printfArray() ;</p>

# Output
<p>45 32 41</p>
<p>32 41 45</p>

# Sample_Input
```

```

# Sample_Ouput
```

```

# Hint


