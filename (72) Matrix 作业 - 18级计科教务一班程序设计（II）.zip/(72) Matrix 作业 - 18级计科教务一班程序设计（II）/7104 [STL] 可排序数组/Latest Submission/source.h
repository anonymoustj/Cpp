#include <iostream>
using namespace std;
template<typename T>
class SortableArray{
	public:
		SortableArray(int n){
			size = 0;
			max_size = n;
			storage = new T[n];
		}
		bool pushBack(T a){
			storage[size] = a;
			size++;
		}
		void sort(void){
			T temp;
			for(int i = 0;i < size-1;i++){
				for(int j = 0;j < size-i-1;j++){
					if(storage[j] > storage[j+1]){
						temp = storage[j];
						storage[j] = storage[j+1];
						storage[j+1] = temp;
					} 
				}
			}
		}
	void printArray(void){
		for(int i = 0;i < size;i++){
			cout << storage[i] << " ";
		}cout << endl;
	}	
	private:
		T* storage;
		int max_size;
		int size;
};