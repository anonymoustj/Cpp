#include<iostream>
#include<string>
using namespace std;
int da[12]={31,30,29,30,31,30,31,31,30,31,30,31};
class Date
{
	private:
		int y,m,d;
public:
  Date(int y=0, int m=1, int d=1)
  {
  	this->y=y;
  	this->m=m;
  	this->d=d;
  };
  ~Date()
  {
  	y=m=d=0;
  }
  static bool leapyear(int year);
  int getYear() const
  {
  	return this->y;
  };
  int getMonth() const
  {
  	return this->m;
  };
  int getDay() const
  {
  	return this->d;
  };
  Date& operator--(int)
  {
  	Date *n;
	n=new Date(this->y,this->m,this->d);
  	d--;
  	if(d==0)
  	{
  		m--;
  		if(m==0)
  		{
  			m=12;
  			y--;
  			d=31;
		  }
		else if(m==2)
		{
			if(y%4==0&&y%100!=0||y%400==0)
			{
				d=29;
			}
			else
			{
				d=28;
			}
		}
		else
		{
			d=da[m-1];
		}
	  }
	  return *n;
};
  friend ostream& operator<<(ostream&, const Date&);
  Date& operator++(int)
  {
  	Date *n;
	n=new Date(this->y,this->m,this->d);
  	d++;
  	if(m==2)
  	{
  		if(y%4==0&&y%100!=0||y%400==0)
  		{
  			if(d==30)
  			{
  				d=1;
  				m=3;
			  }
		  }
		  else
		  {	
		  	if(d==29)
  			{
  				d=1;
  				m=3;
			  }
		  }
	  }
	  else if(d==da[m-1]+1)
	  {
	  	d=1;
	  	m++;
	  	if(m==13)
	  	{
	  		m=1;
	  		y++;
		  }
	  }
	  return *n;
};
Date& operator++(void)
  {
  	d++;
  	if(m==2)
  	{
  		if(y%4==0&&y%100!=0||y%400==0)
  		{
  			if(d==30)
  			{
  				d=1;
  				m=3;
			  }
		  }
		  else
		  {	
		  	if(d==29)
  			{
  				d=1;
  				m=3;
			  }
		  }
	  }
	  else if(d==da[m-1]+1)
	  {
	  	d=1;
	  	m++;
	  	if(m==13)
	  	{
	  		m=1;
	  		y++;
		  }
	  }
	  return *this;
  };
Date& operator--(void)
{
  	d--;
  	if(d==0)
  	{
  		m--;
  		if(m==0)
  		{
  			m=12;
  			y--;
  			d=31;
		  }
		else if(m==2)
		{
			if(y%4==0&&y%100!=0||y%400==0)
			{
				d=29;
			}
			else
			{
				d=28;
			}
		}
		else
		{
			d=da[m-1];
		}
	  }
	  return *this;
};
};