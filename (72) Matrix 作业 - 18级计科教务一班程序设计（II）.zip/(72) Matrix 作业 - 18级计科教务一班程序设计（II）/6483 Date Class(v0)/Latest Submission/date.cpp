#include"date.hpp"
using namespace std;
#include<iostream>
void Date::setDate(int year,int month,int day)
{
month_=month;
day_=day;
year_=year;
return;
}

int Date::month() const
{
return month_;
}

int Date::year() const
{
return year_;
}

int Date::day() const
{
return day_;
}


int Date::daysOfMonth(int year, int month) const
{
if(month==2){
  if(year%4==0&&year%100!=0||year%400==0)
	    {
		return 29;
		}
		else
		{
		return 28;
		}
}
  else if(month==4||month==6||month==9||month==11)
		return 30;
  else
  {
  return 31;
  }
}

void Date::increment()
{
int newMonth=month_;
int newDay=day_;
int newYear=year_;
newDay++;
if(newDay>daysOfMonth(newYear,newMonth))
{
newDay=1;
newMonth++;
}
if(newMonth>12)
{
newMonth=1;
newYear++;
}
Date::setDate(newYear,newMonth,newDay);
return;
	
}

void Date::decrement()
{
int newMonth=month_;
int newDay=day_;
int newYear=year_;
newDay--;
if(newDay==0)
{
newMonth--;
if(newMonth==0)
{
newMonth=12;
newYear--;
}
newDay=daysOfMonth(newYear,newMonth);
}

Date::setDate(newYear,newMonth,newDay);
return;
	
}
