#include <iostream>

using namespace std;

int main() {
  int m, s, t;
  while (cin >> m >> s >> t) {
    // 贪心算法： 贪心策略为能闪烁则闪烁
    int flash_distance = 0;
    int distance = 0;
    bool flag = false;
    for (int time = 1; time <= t; time++) {
      distance += 17;

      if (m >= 10) {
        m -= 10;
        flash_distance += 60;
      } else {
        m += 4;
      }
      distance = max(distance, flash_distance);
      if (distance >= s) {
        cout << "Yes" << endl
             << time << endl;
        flag = true;
        break;
      }
    }
    if (!flag) {
      cout << "No" << endl
           << distance << endl;
    }
  }
  return 0;
}