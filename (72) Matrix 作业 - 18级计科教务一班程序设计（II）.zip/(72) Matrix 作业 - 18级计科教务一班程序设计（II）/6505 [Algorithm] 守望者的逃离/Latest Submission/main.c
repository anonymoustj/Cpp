#include<iostream>
using namespace std;
int main()
{
	int M,S,T,mo=0,di,od,t=0,t1=0,l=0,j;
	while(cin>>M>>S>>T)
	 {
	 	t=0;
		j=S;
	    while(t1<T&&S>0)
	    {
	    	if(t+1==T)
	    	{
	    		t1++;
			}
	        while(M>=10&&t<T&&S>0)
			{
		        M-=10;
		        t++;
		        S-=60;
		        t1=t;
	        }
	        if(M<10&&M>=6&&S>0)
	        {
	        	if(S<18&&t<T)
	        	{
	        		t++;
	        		S-=17;
				}
				else if(t+1<T)
				{
	        		M+=4;
					t+=2;
					S-=60;
					M%=10;
				}
			}
			else if(M<10&&M>=2&&S>0)
			{
				if(S<35&&t+1<T)
				{
					t+=2;
					S-=34;
				}
				else if(t+1<T)
				{
					t+=3;
					M+=8;
					M%=10;
					S-=60;
				}
				t1=t+1;
			}
			else if(M<10&&t<T&&S>0)
			{
				t++;
				S-=17;
				t1=t;
			}
		}
		if(S<=0)
		{
			cout<<"Yes\n"<<t<<endl;
		}
		else if(t+1==T)
		{
			cout<<"No\n"<<j-S+17<<endl;
		}
		else if(t==T)
		{
			cout<<"No\n"<<j-S<<endl;
		}
		else
		{
			
			cout<<"No\n"<<j-S+34<<endl;
		}
    }
	return 0;
}