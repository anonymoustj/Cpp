#include <iostream>
#include <set>
using namespace std;
int main()
{
    int iarr[] = {1, 1, 2, 3, 3};
    double darr[] = {4.4, 5.6, 2.1, 7.8, 8.8, 9.8, 1.1};

    set<int>iset(iarr,iarr+5);

    set<double> dset;           // ´´½¨¿ÕµÄset¶ÔÏó

    // Êä³öset¶ÔÏóisetÖÐµÄÔªËØ
    cout << "content of the integer set container:" << endl;
    for (set<int>::iterator iter = iset.begin(); iter != iset.end(); iter++)
        cout << *iter << " ";
    cout << endl;

    // ÔÚiset¶ÔÏóÖÐ²éÕÒÌØ¶¨ÔªËØ
    if (iset.find(2) != iset.end())
        cout << "2 is a element in the integer set container" << endl;
    else
        cout << "2 is not a element in the integer set container" << endl;
    if (iset.find(6) != iset.end())
        cout << "6 is a element in the integer set container" << endl;
    else
        cout << "6 is not a element in the integer set container" << endl;

    dset.insert(1.2);
    dset.insert(3.4);
    dset.insert(3.4);

    dset.insert(darr,darr+7);

    cout << endl;

    // Êä³öset¶ÔÏódsetÖÐµÄÔªËØ
    cout << "content of the double set container:" << endl;
    for (set<double>::iterator iter = dset.begin(); iter != dset.end(); iter++)
        cout << *iter << " ";
    cout << endl;

    dset.erase(1.1);

    dset.erase(dset.find(3.4),dset.find(7.8));

    // Êä³öset¶ÔÏódsetÖÐµÄÔªËØ
    cout << "content of the double set container(after delete):" << endl;
    for (set<double>::iterator iter = dset.begin(); iter != dset.end(); iter++)
        cout << *iter << " ";

    return 0;
}