#include<iostream>
using namespace std;

void traverse_preorder(int* tree, int i, int n) {
	int left_child = i * 2 + 1, right_child = i * 2 + 2;
	if (i < n)
		cout << tree[i] << endl;
	else
		return;
	traverse_preorder(tree, left_child, n);
	traverse_preorder(tree, right_child, n);
}

void traverse_inorder(int* tree, int i, int n) {
	int left_child = i * 2 + 1, right_child = i * 2 + 2;
	if (i >= n)
		return;
	traverse_inorder(tree, left_child, n);
	cout << tree[i] << endl;
	traverse_inorder(tree, right_child, n);
}

void traverse_postorder(int* tree, int i, int n) {
	int left_child = i * 2 + 1, right_child = i * 2 + 2;
	if (i >= n)
		return;
	traverse_postorder(tree, left_child, n);
	traverse_postorder(tree, right_child, n);
	cout << tree[i] << endl;
}

int main(void) {
	int tree[1024], n, i;
	cin >> n;
	for (i = 0; i < n; i++) {
		cin >> tree[i];
	}
	cout << "Preorder" << endl;
	traverse_preorder(tree, 0, n);
	cout << "Inorder" << endl;
	traverse_inorder(tree, 0, n);
	cout << "Postorder" << endl;
	traverse_postorder(tree, 0, n);

	return 0;
}
