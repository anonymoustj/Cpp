#include<iostream>
#include<cstring>
using namespace std;
void leftprint(int *,int ,int );
void mprint(int *,int ,int );
void rightprint(int *,int ,int );
int main()
{
using namespace std;
int num,br[33],node=0;
cin>>num;
for(int i=0;i<num;i++)
{
cin>>br[i];
}
cout<<"Preorder\n";
leftprint(br,node,num);
cout<<"Inorder\n";
mprint(br,node,num);
cout<<"Postorder\n";
rightprint(br,node,num);
return 0;
}

void leftprint(int *br,int node,int num)
{
	cout<<br[node]<<endl;
	if(2*node+1<num)
	leftprint(br,2*node+1,num);
	if(2*node+2<num){
	    leftprint(br,2*node+2,num);
	}
	return;
}

void mprint(int *br,int node,int num)
{
	if(2*node+1<num){
	    mprint(br,2*node+1,num);
	}
	cout<<br[node]<<endl;
	if(2*node+2<num)
	    mprint(br,2*node+2,num);
	
}

void rightprint(int *br,int node,int num)
{
	if(2*node+1<num)
	    rightprint(br,2*node+1,num);
	if(2*node+2<num)
	    rightprint(br,2*node+2,num);
	cout<<br[node]<<endl;
}
