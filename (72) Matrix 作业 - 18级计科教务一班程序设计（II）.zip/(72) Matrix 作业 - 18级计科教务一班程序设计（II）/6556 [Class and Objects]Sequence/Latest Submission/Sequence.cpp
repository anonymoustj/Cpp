#include<iostream>
#include"Sequence.h"
using namespace std;
Sequence::Sequence()
{
	a=new int[2000];
  for(int i=0;i<2000;i++)
  {
  a[i]=0;
  }
	msize=0;
}
Sequence::~Sequence()
{
	delete [] a;
	msize=0;
}
	int Sequence::size()
	{
		return msize;
	}
	bool Sequence::empty()
	{
		if(msize==0)
		return true;
		else
		return false;
	}
	bool Sequence::find(int value)
	{
		for(int i=0;i<msize;i++)
		{
			if(value==a[i])
			return true;
		}
		return false;
	}
	int &Sequence::at(int pos)
	{
		return a[pos];
	}
	int Sequence::front()
	{
		return a[0];
	}
	int Sequence::back()
	{
		return a[msize-1];
	}
	void Sequence::insert(int value)
	{
		a[msize++]=value;
	}
	void Sequence::insert(int pos, int value)
	{
		int i;
	msize++;
	for(i=msize-1;i>pos;i--)
	{
		a[i]=a[i-1];
	}
	a[pos]=value;
	
	}
	void Sequence::clear()
	{
		msize=0;
	}
	void Sequence::reverse()
	{
		int temp;
		for(int i=0, j=msize-1;i<j;i++,j--)
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
	void Sequence::reverse(int fir, int las)
	{
		int temp;
		for(int i=fir, j=las-1;i<j;i++,j--)
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
	void Sequence::replace(int value1, int value2)
	{
		for(int i=0;i<msize;i++)
		
			if(value1==a[i])
			a[i]=value2;
			
		
	}


	void Sequence::swap(Sequence &seq2)
	{
    int b[2000],i,t,size;
	for(i=0;i<=seq2.msize-1;i++)
	{
		b[i]=seq2.a[i];
	}
	size=seq2.msize;
    
	t=msize;
	for(i=0;i<=msize-1;i++)
	{
		seq2.a[i]=a[i];
	}
	msize=size;
	for(i=0;i<=seq2.msize-1;i++)
	{
		a[i]=b[i];
	}  
	seq2.msize=t;
	}