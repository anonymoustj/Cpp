#ifndef List_hpp
#define List_hpp
#include"Collection.hpp"
class List: virtual public Collection
{
	public:
  virtual ~List(){
		};
 		virtual E& operator[](int index)=0;
  		virtual E& get(int index)=0;
  		virtual int indexOf(E element)=0;
  		virtual void sort(void)=0;
  		
};
#endif