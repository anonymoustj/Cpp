#include"ArrayList.hpp"
ArrayList::ArrayList()
{
	_size=0;
	_maxsize=10000;
	storage=new int[_maxsize];
}
ArrayList::~ArrayList()
{
	clear();
}
void ArrayList::add(E e)
{
	storage[_size]=e;
	_size++;
}
void ArrayList::clear(void)
{
	delete[] storage;
}
bool ArrayList::contain(E e)
{
	int i;
	for(i=0;i<_size;i++)
	{
		if(storage[i]==e)return true;
	}
	return false;
}
bool ArrayList::isEmpty(void)
{
	if(_size==0)return true;
	else return false; 
} 
void ArrayList::remove(E e)
{
	int i,j;
	for(i=0;i<_size;i++)
	{
		if(e==storage[i])
		{
			for(j=i;j<_size-1;j++)
			{
				storage[j]=storage[j+1];
			}
			i--;
			_size--;
		}
	}
}
E& ArrayList::operator[](int index)
{
	return storage[index];
}
E& ArrayList::get(int index)
{
	return storage[index];
}
int ArrayList::indexOf(E element)
{
	int i;
	for(i=0;i<_size;i++)
	{
		if(storage[i]==element)
		return i;
	}
	return -1;
}
void swap(int *a,int *b)
{
	int temp;
	temp=*a;
	*a=*b;
	*b=temp;
}
void quicksort(int arr[],int left,int right)
{
	int i, j;
    if (left < right) {
        i = left;
        j = right + 1;
        while (1) {
            do {
                i++;
            } while (!(arr[i] >= arr[left] || i == right));
            do {
                j--;
            } while (!(arr[j] <= arr[left] || j == left));
            if (i < j)
                swap(&arr[i], &arr[j]);
            else
                break;
        }
        swap(&arr[left], &arr[j]);
        quicksort(arr, left, j - 1);
        quicksort(arr, i, right);
    }
}
void ArrayList::sort(void)
{
	quicksort(storage,0,_size-1);
}
int ArrayList::size(void)
{
	return _size;
}
void ArrayList::extend(void){}