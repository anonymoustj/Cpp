#include"LinkedList.hpp"
void swa(int &a,int &b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;
}
int partitio(int *a,int lo,int hi)
{
	int pivot=a[hi];
	int i=lo;
	for(int j=lo;j<hi;j++)
	{
		if(a[j]<=pivot)
		{
			swa(a[i],a[j]);
			i++;
		}
	}
	swa(a[i],a[hi]);
	return i;
}
void quicksor(int a[],int lo,int hi)
{
	if(lo<hi)
	{
		int p=partitio(a,lo,hi);
		quicksor(a,lo,p-1);
		quicksor(a,p+1,hi);
	}
}
LinkedList:: LinkedList()
{
	head=tail=NULL;
	_size=0;
}
LinkedList::~LinkedList()
{
	clear();
}
void LinkedList::add(E e)
{
	if(head==NULL)
	{
		head=new node(e);
		tail=head;
		_size++;
	}
	else
	{
		node *temp=new node(e);
		temp->prev=tail;
		tail->next=temp;
		tail=temp;
		_size++;
	}
}
void LinkedList::clear(void)
{
	node *a=head,*b;
	while(_size--)
	{
		b=a->next;
		delete a;
		a=b;
	}
}
bool LinkedList::contain(E e)
{
	node *a=head;
	while(a!=NULL)
	{
		if(a->data==e)
		return true;
    a=a->next;
	}
	return false;
}
bool LinkedList::isEmpty(void)
{
	if(_size==0)return true;
	else return false;
}
void LinkedList::remove(E e)
{
	node *a=head,*b;
	while(a!=NULL)
	{
		if(a->data==e)
		{
			if(a==head)
			{
				head=a->next;
				if(head!=NULL)head->prev=NULL;
				if(_size==1)tail=NULL; 
				delete a;
				a=head;
			}
			else if(a==tail)
			{
				tail=a->prev;
				if(tail!=NULL)tail->next=NULL;
				if(_size==1)head=NULL;
				delete a;
				a=NULL;
			}
			else
			{
				a->prev->next=a->next;
				a->next->prev=a->prev;
				b=a;
				a=a->next;
				delete b;
			}
			_size--;
		}else a=a->next;
	}
}
E& LinkedList::operator[](int index)
{
	return get(index);
}
E& LinkedList::get(int index)
{
	node *a=head;
	int i;
	for(i=0;i<index;i++)
	{
		a=a->next;
	}
	return a->data;
}
int LinkedList::indexOf(E element)
{
	node *a=head;
	int i;
	for(i=0;i<_size;i++)
	{
		if(a->data==element)
		return i;
		a=a->next;
	}
	return -1;
}
void LinkedList::sort(void)
{
	node *b=head;
	int a[10000],i,j;
	for(i=0;i<_size;i++)
	{
		a[i]=b->data;
		b=b->next;
	}
	quicksor(a,0,_size-1);
	b=head;
	for(i=0;i<_size;i++)
	{
		b->data=a[i];
		b=b->next;
	}
}
int LinkedList::size(void)
{
	return _size;
}