#include<iostream>
#include<string>
using namespace std;
template < typename T >
T maxValue (const T value1, const T value2)
{
	if(value1>=value2)
	{
		return value1;
	}
	else
	{
		return value2;
	}
}

template <> char maxValue<char>(const char value1,const char value2)
{
	char va1=value1,va2=value2;
	if(va1>='a')
	{
		va1-=32;
	}
	if(va2>='a')
	{
		va2-=32;
	}
	if(va1>=va2)
	{
		return value1;
	}
	else
	{
		return value2;
	}
}