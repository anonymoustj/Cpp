# [Template] MaxValue template function

# MaxValue template function

# Description
<p>Design a generic function that returns a maximum element from an array. You should test your function with the array of int, double, std::string&nbsp;and char.<br />
Using the following function header:<br />
template &lt; typename T &gt;<br />
T maxValue (const T value1, const T value2)<br />
当比较两个char大小时，如果char是字母，将其视为大写字母进行比较。<br />
当两个char大小相等时，返回value1.<br />
例如，maxValue('B','a')返回B, maxValue('B','b')返回B, maxValue('B','c')返回c.<br />
&nbsp;</p>

# Input


# Output


# Sample_Input
```

```

# Sample_Ouput
```

```

# Hint


