#include <iostream>
using namespace std;

extern void TestObjects();

int main()
{
  TestObjects();
    return 0;
}
