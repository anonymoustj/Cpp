#include"Object.h"
void TestObjects()
{
	Object o1(1);
	{
		
	Object o2(2);
	Object o3(3);
	}
	{
		
	Object o4(4);
	}
}