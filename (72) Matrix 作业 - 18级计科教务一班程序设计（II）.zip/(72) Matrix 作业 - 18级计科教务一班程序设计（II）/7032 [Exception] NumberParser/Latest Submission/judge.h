#include <iostream>
#include <string>
#include<string.h>
#include <stdio.h>
using namespace std;
#include<math.h>
class NumberParseException
{
};
int parseNumber(const char *str)
        {
        	int sum=0;       	
        	if(str==NULL) throw NumberParseException();int j=strlen(str);
        	if(str[0]=='+'||str[0]=='-')
        	{
        		if(j==1) throw NumberParseException();
        		for(int i=1;i<strlen(str);i++)
        		{
        			if(str[i]>57||str[i]<48)
        			throw NumberParseException();
        			else
        			{
        				sum+=(str[i]-'0')*pow(10,j-i-1);
					}
				}
				if(str[0]=='-')
				return -sum;
				else return sum;
			}
			else if(str[0]<=57&&str[0]>=48)
			{
        		for(int i=0;i<strlen(str);i++)
        		{
        			if(str[i]>57||str[i]<48)
        			throw NumberParseException();
        			else
        			{
        				sum+=(str[i]-'0')*pow(10,j-i-1);
					}
				}
				return sum;
			}
			else throw NumberParseException();
        }