# [Exception] NumberParser

### Your job is to finish two function `int parseNumber(const char *str) & bool isNumber(const char* str)` and create a class named `NumberParseException`.
### Most of you had learned it from class, so there will be no more information for u.Just see some examples.

### Sample Input1
```
0
1 2
```
### Sample Output1
```
Not a number.
Not a number.
sum is 3
```
### Sample Input2
```
0
1.1 1.2
```
### Sample Output2
```
Not a number.
Not a number.
Not a number.
```