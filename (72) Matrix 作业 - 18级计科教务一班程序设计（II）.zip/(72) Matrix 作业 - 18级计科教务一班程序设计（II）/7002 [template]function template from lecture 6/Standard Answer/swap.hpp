namespace myNamespace
{
template <class T>
void swap(T &v1, T &v2)
{
       T temp;
       temp = v1;
       v1 = v2;
       v2 = temp;
}
} // namespace myNamespace