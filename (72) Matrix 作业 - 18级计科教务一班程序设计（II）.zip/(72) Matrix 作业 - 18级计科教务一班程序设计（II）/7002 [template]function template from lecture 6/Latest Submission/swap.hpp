namespace  myNamespace  
{
    template <typename T>
    void swap (T&a,  T&b ) 
{
    T tamp;
    tamp = a;
    a = b;
    b = tamp;
}
}

