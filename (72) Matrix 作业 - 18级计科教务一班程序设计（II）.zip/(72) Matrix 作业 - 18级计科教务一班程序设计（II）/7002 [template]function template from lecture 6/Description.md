# [template]function template from lecture 6

## Description
Implement the template ```swap``` function, which swaps the two arguments.
## Output
```
s1: bear, s2: rabbit
iv1: 5, iv2: 3
dv1: 8.5, dv2 2.8

```