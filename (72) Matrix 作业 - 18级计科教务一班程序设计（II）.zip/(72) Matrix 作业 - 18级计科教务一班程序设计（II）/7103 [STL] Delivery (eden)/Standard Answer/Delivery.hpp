#include <vector>
#include <string>
#include <algorithm>
#include <map>
 using std::string;
 bool cmp(const std::pair<string, string> a, std::pair<string, string> b) {
    return a.first < b.first;
}
  std::vector<string> getInfoSort(std::vector<string> info) {
    std::vector<string> result;
    std::map<string, string> myMap;
        for (std::vector<string>::iterator it = info.begin();
         it != info.end();
         it++) {
        string temp = *it;
        int pos = temp.find_first_of("\\|", 0);
        string time = temp.substr(0, pos);
        string message = temp.substr(pos + 1);
                std::map<string, string>::iterator findIt = myMap.find(message);
                if (findIt != myMap.end()) {
            if ((findIt->second).compare(time) > 0) {
                findIt->second = time;
            }
        } else {
            myMap.insert(myMap.begin(), std::pair<string, string>(message, time));
        }
    }
        std::vector< std::pair<string, string> > sortVec;
            for (std::map<string, string>::iterator it = myMap.begin();
         it != myMap.end();
         it++) {
        sortVec.push_back(make_pair(it->second, it->first));
     }
    std::sort(sortVec.begin(), sortVec.end(), cmp);
    for (std::vector< std::pair<string, string> >::iterator it = sortVec.begin();
         it != sortVec.end();
         it++) {
        result.push_back(it->first + " : " + it->second);
            }
    return result;
}
 