#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <string>
using namespace std;
vector<string> getInfoSort(vector<string> info){
	string time;
	string state;
	string str;
	string s1,s2;
	vector<string> v;
	map<string,string>m1;
	map<string,bool>m2;
	int size = info.size();
	for(int i = 0;i < size;i++){
		time = info[i].substr(0,19);
		state = info[i].substr(20,info[i].size()-20);
		m2[state] = 0;
		if(m1.find(state) == m1.end())
			m1[state] = time;
		else{
			if(time < m1[state])
				m1[state] = time;
		}
	}
	for(int i = 0;i < size;i++){
		state =  info[i].substr(20,info[i].size()-20);
		if(m2[state]) continue;
		m2[state] = 1;
		str = m1[state] + " : " + state;
		v.push_back(str);
	}
	for(int i = 0;i < v.size()-1;i++){
		for(int j = 0;j < v.size()-1-i;j++){
			if(v[j].substr(0, 19) > v[j+1].substr(0, 19))
			swap(v[j],v[j+1]);
		}
	}return v;
}