#ifndef _DATE_H_
#define _DATE_H_
 
#include <string>
#include <sstream>
#include <iostream>
using namespace std;
class Date {
  private:
    int _year;
    int _month;
    int _day;
  public:
    Date(int y, int m, int d) : _year(y), _month(m), _day(d) {}
    Date(string s) {
        for (char &c : s) {
            if (!isdigit(c))
                c = ' ';
        }
        stringstream ss;
        ss << s;
        ss >> _year >> _month >> _day;
    }
 
    int getYear() const {
        return _year;
    }
 
    void setYear(int y) {
        _year = y;
    }
 
    int getMonth() const {
        return _month;
    }
 
    void setMonth(int m) {
        _month = m;
    }
 
    int getDay() const {
        return _day;
    }
 
    void setDay(int d) {
        _day = d;
    }
 
    bool operator==(Date& other) const {
        return (_year == other._year && _day == other._day && _month == other._month);
    }

    bool operator<(Date& other) const {
        if (_year < other._year) return true;
        else if (_year == other._year && _month < other._month) return true;
        else if (_year == other._year && _month == other._month && _day < other._day) return true;
        return false;
    }

    bool operator>(Date& other) const {
        return !(*this < other || *this == other);
    }

    std::string toString() const {
        std::stringstream ss;
        ss << getYear() << '-' << getMonth() << '-' << getDay();
        return ss.str();
    }
};
 
#endif