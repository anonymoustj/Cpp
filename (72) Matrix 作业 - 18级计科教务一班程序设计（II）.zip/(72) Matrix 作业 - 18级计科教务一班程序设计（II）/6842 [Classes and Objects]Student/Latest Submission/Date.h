#ifndef DATE_H
#define DATE_H
#include<iostream>
#include<sstream>
using namespace std;
class Date {
  private:
    int _year;
    int _month;
    int _day;
  public:
    Date(int y=0, int m=0, int d=0);
    Date(string dateString); // the format of dateString is like "2017-5-7"
    int getYear() const;
    void setYear(int y);
    int getMonth() const;
    void setMonth(int m);
    int getDay() const;
    void setDay(int d);
    bool operator==(Date& other) const;
    bool operator<(Date& other) const;
    bool operator>(Date& other) const;
    std::string toString() const; // return a string like "year-month-day"
};
Date::Date(int y, int m, int d)
{
	_year=y;
	_month=m;
	_day=d;
}
Date::Date(string dateString) // the format of dateString is like "2017-5-7"
{
	int y=0,m=0,d=0,i=0,j=0,num=0;
	while(dateString[i]!='-')
	{
		num*=10;
		num=num+dateString[i]-'0';
		i++;
	}
	y=num;
	num=0;
	i++;
  	while(dateString[i]!='-')
	{
		num*=10;
		num=num+dateString[i]-'0';
		i++;
	}
	m=num;
	num=0;
	i++;
	while(dateString[i]!='-'&&dateString[i])
	{
		num*=10;
		num=num+dateString[i]-'0';
		i++;
  	}
	d=num;
	num=0;
	_year=y;
	_month=m;
	_day=d;
}
int Date::getYear() const
{
	return _year;
}
void Date::setYear(int y)
{
	_year=y;
}
int Date::getMonth() const
{
	return _month;
}
void Date::setMonth(int m)
{
	_month=m;
}
int Date::getDay() const
{
	return _day;
}
void Date::setDay(int d)
{
	_day=d;
}
bool Date::operator==(Date& other) const
{
	if(other.getYear()==_year&&other.getMonth()==_month&&other.getDay()==_day)
	{
		return true;
	}
  else
	{
		return false;
	}
}
bool Date::operator>(Date& other) const
{
	if(other.getYear()<_year||other.getYear()==_year&&other.getMonth()<_month||other.getYear()==_year&&other.getMonth()==_month&&other.getDay()<_day)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Date::operator<(Date& other) const
{
	if(other.getYear()>_year||other.getYear()==_year&&other.getMonth()>_month||other.getYear()==_year&&other.getMonth()==_month&&other.getDay()>_day)
	{
		return true;
	}
	else
	{
		return false;
	}
}
std::string Date::toString() const
{
	string str,str1;
	stringstream ss,s2,s3;
	ss<<_year;
	ss>>str1;
	str+=str1;
	str+="-";
	s2<<_month;
	s2>>str1;
	str+=str1;
	str+="-";
	s3<<_day;
	s3>>str1;
	str+=str1;
	return str;
}
#endif