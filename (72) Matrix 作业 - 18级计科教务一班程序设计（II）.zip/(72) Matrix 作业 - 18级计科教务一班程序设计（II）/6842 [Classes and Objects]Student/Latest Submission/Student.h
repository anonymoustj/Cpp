#include<iostream>
#include<sstream>
using namespace std;
#include"Person.h"
#include"Date.h"
class Student:public Person
{
	private:
		Date graduateDate;
	public:
		using Person::set;
		void set(Date &d)
		{
			graduateDate=d;
		};
		Student(string name,int age,Date &d):Person(name,age)
		{
			graduateDate=d;
		};
		void sayHi() const
		{
			Person::sayHi();
			string str=graduateDate.toString();
			if(graduateDate.getYear()<2017||graduateDate.getYear()==2017&&graduateDate.getMonth()<5||graduateDate.getYear()==2017&&graduateDate.getMonth()==5&&graduateDate.getDay()<7)
			{
				cout<<"I have graduated on "<<str<<".\n";
			}
			else if(graduateDate.getYear()==2017&&graduateDate.getMonth()==5&&graduateDate.getDay()==7)
			{
				cout<<"I graduated today!\n";
			}
			else
			{
				cout<<"I will graduate on "<<str<<".\n";
			}
		};
		virtual ~Student()
	{};
  };
  