#include<iostream>
#include<cstring>
using namespace std;

class Student
{
public:
  int id;
  char *name; // Data field
  int age; // Data field
  Student();
  Student(int, char* ="No Name", int=0);
  //void set(int, char*, int);
  //void print();
};

void set(Student &, int, char*, int);
void print(Student);

void set(Student & c, int a, char* b, int d)
{
	c.id=a;
	c.name=b;
	c.age=d;

}
void print(Student c)
{
	cout<<c.name<<" ("<<c.id<<") is "<<c.age<<" years old."<<endl;
}
Student::Student(int a, char* d, int b)
{
	this->id=a;
	this->name=d;
	this->age=b;
	
}
Student::Student()
{
  this->id=0;
  this->name="No Name";
  this->age=0;
}