#include <iostream>
using namespace std;
class Car
{
	public:
		Car()
		{
			cout<<"Construct a car\n";
		};
		~Car()
		{
			
		};
};
class Wheel
{
	public:
		Wheel()
		{
			cout<<"Construct a wheel\n";
		};
		~Wheel()
		{
			
		};
};
class RedCar:public Car
{
	private:
		Wheel w1,w2,w3,w4;
	public:
		RedCar()
		{
			cout<<"Construct a red car\n";
		};
		~RedCar()
		{
			
		};
};