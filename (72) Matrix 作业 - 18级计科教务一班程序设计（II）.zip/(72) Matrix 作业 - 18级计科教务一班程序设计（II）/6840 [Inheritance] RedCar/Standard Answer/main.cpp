#include <iostream>

#include "class.hpp"

using namespace std;

int main() {
  cout << "--- build car ---" << endl;
  Car car;
  cout << endl;

  cout << "--- build wheel ---" << endl;
  Wheel wheel;
  cout << endl;

  cout << "--- build red car ---" << endl;
  RedCar redcar;

  return 0;
}