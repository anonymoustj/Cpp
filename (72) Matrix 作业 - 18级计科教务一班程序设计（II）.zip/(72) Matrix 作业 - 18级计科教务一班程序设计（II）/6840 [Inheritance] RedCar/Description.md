# [Inheritance] RedCar

# 描述
红色小汽车是一种汽车,它有四个轮子.

有三个类 `Car`, `Wheel`, `RedCar`. `RedCar`继承`Car`,并且有四个`Wheel`成员对象

三个类都有自己的默认构造函数,并且调用默认构造函数时,会输出一句话`Construct a XXX`

根据要求完成类的定义

# 输入
```

```

# 输出
```
--- build car ---
Construct a car

--- build wheel ---
Construct a wheel

--- build red car ---
Construct a car
Construct a wheel
Construct a wheel
Construct a wheel
Construct a wheel
Construct a red car
```