#include"fraction.h"
#include<iostream>
using namespace std;
long long int gcd_2(long long int a,long long int b)
{
	long long int temp=0,a1=abs(a),b1=abs(b);
	if(b>a)
	{
		a1=b;
		b1=a;
	}
	while(b1!=0)
	{
		temp=b1;
		b1=a1%b1;
		a1=temp;
	}
	if(a<0&&b<0)
	return -a1;
	else
	return a1;
}
int fraction::gcd(const int &a, const int &b) const
{
	
	int temp=0,a1=abs(a),b1=abs(b);
	if(b>a)
	{
		a1=b;
		b1=a;
	}
	while(b1!=0)
	{
		temp=b1;
		b1=a1%b1;
		a1=temp;
	}
	if(a<0&&b<0)
	return -a1;
	else
	return a1;
}
void fraction::simp()
{
	int num=this->gcd(this->_denominator,this->_numerator);
	this->_denominator/=num;
	
	this->_numerator/=num;
}
fraction::fraction(const int & a, const int & b)
{
	this->_numerator=a;
	this->_denominator=b;
}
            // The numerator and the denominator
            // fraction(5) = 5/1 = 5 :)
fraction::fraction(const fraction & other)
{
	this->_denominator=other._denominator;
	this->_numerator=other._numerator;
}
            // copy constructor

void fraction::operator=(const fraction & other)
{
	this->_denominator=other._denominator;
	this->_numerator=other._numerator;
}

        // You must know the meaning of +-*/, don't you ?
fraction fraction::operator+(const fraction & other) const
{
	
	fraction new_fraction;
	long long int num1=other._numerator,num3=0,num4=0,t=0;
	long long int num2=other._denominator;
	num3=num2*this->_denominator;
	num4=this->_numerator*num2+this->_denominator*num1;
	t=gcd_2(num3,num4);
	num3/=t;
	num4/=t;
	new_fraction._denominator=(int)num3;
	new_fraction._numerator=(int)num4;
	new_fraction.simp();
	return new_fraction;
}
fraction fraction::operator-(const fraction & other) const
{
	fraction new_fraction;
	long long int num1=other._numerator,num3=0,num4=0,t=0;
	long long int num2=other._denominator;
	num3=num2*this->_denominator;
	num4=this->_numerator*num2-this->_denominator*num1;
	t=gcd_2(num3,num4);
	num3/=t;
	num4/=t;
	new_fraction._denominator=(int)num3;
	new_fraction._numerator=(int)num4;
	new_fraction.simp();
	return new_fraction;
}
fraction fraction::operator*(const fraction & other) const
{
	fraction new_fraction;
	long long int num1=other._numerator,num3=0,num4=0,t=0;
	long long int num2=other._denominator;
	num3=num2*this->_denominator;
	num4=this->_numerator*num1;
	t=gcd_2(num3,num4);
	num3/=t;
	num4/=t;
	new_fraction._denominator=(int)num3;
	new_fraction._numerator=(int)num4;
	new_fraction.simp();
	return new_fraction;
}
fraction fraction::operator/(const fraction & other) const
{
	fraction new_fraction;
	long long int num1=other._numerator,num3=0,num4=0,t=0;
	long long int num2=other._denominator;
	num3=num1*(this->_denominator);
	num4=this->_numerator*num2;
	t=gcd_2(num3,num4);
	num3/=t;
	num4/=t;
	new_fraction._denominator=(int)num3;
	new_fraction._numerator=(int)num4;
	new_fraction.simp();
	return new_fraction;
}

void fraction::operator+=(const fraction & other)
{
	*this = *this+other;
}
void fraction::operator-=(const fraction & other)
{
	*this=*this-other;
}
void fraction::operator*=(const fraction & other)
{
	*this=(*this)*other;
}
void fraction::operator/=(const fraction & other)
{
	*this=(*this)/other;
}

        // Comparison operators
bool fraction::operator==(const fraction & other) const
{
	fraction new_fraction=*this-other;
	if(new_fraction._numerator==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool fraction::operator!=(const fraction & other) const
{
	if(!(*this==other))
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool fraction::operator<(const fraction & other) const
{
	if((long long int)(this->_numerator*other._denominator-this->_denominator*other._numerator)*(this->_denominator*other._denominator)<0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool fraction::operator>(const fraction & other) const
{
	if((long long int)(this->_numerator*other._denominator-this->_denominator*other._numerator)*(this->_denominator*other._denominator)>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool fraction::operator<=(const fraction & other) const
{
	if((*this<other)||(*this==other))
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool fraction::operator>=(const fraction & other) const
{
	if((*this>other)||(*this==other))
	{
		return true;
	}
	else
	{
		return false;
	}
}
std:: istream &operator>>(std::istream &in,fraction &thiz)
{
	in>>thiz._numerator;
	in>>thiz._denominator;
	thiz.simp();
    return in;
}
// Input Format: two integers with a space in it
// "a b" is correct. Not "a/b"
 std::ostream & operator<<(std::ostream &out, const fraction &thiz)
{
	if(thiz._numerator<0&&thiz._denominator>0||thiz._numerator>0&&thiz._denominator<0)
	{
		out<<"-";
	}
	out<<abs(thiz._numerator)<<"/"<<abs(thiz._denominator);
    return out;
}