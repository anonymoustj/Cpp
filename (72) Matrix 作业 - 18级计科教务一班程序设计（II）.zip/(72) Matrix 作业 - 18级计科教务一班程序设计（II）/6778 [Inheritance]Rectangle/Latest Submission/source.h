class Point{  
    int x,y;
public:
    Point(int x,int y);
    void Move(int x,int y);
    int Getx();
    int Gety();
};
class Rectangle:public Point{
	private:
		int lenth;
		int high;
	public:
		Rectangle(int x,int y,int lenth,int high);
		int Getarea(); 
		int Getlength();
		int Getwidth();
}; 
Point::Point(int x,int y){
	this->x = x;
	this->y = y;
}
void Point::Move(int x,int y){
	this->x += x;
	this->y += y;
}
int Point::Getx(){
	return x;
}
int Point::Gety(){
	return y;
}
Rectangle::Rectangle(int x,int y,int lenth,int high):Point(x,y){
	this->lenth = lenth;
	this->high = high;
}
int Rectangle::Getarea(){
	return lenth*high;
}
int Rectangle::Getlength(){
	return lenth;
}
int Rectangle::Getwidth(){
	return high;
}

