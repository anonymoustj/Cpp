#include<iostream>
#include "Stack.hpp"
using namespace std;
const int N=100000;

Stack::Stack(){
    data=NULL;
}

Stack::Stack(const Stack& x){
    int index=0,temp[N];
    node *current = x.data;
    while(current!=NULL){
        temp[++index]=current->num;
        current = current->next;
    }
    node *ptr=NULL;
    for(int i=index;i>=1;i--){
        node *current = new node(temp[i],ptr);
        ptr = current;
    }
  data = ptr;
}

Stack::~Stack(){
    clear(); 
}

Stack Stack::operator=(const Stack& sta){
    Stack x=Stack(sta);
    clear();
    int index=0,temp[N];
    node *current = x.data;
    while(current!=NULL){
        temp[++index]=current->num;
        current = current->next;
    }
    node *ptr=NULL;
    for(int i=index;i>=1;i--){
        node *current = new node(temp[i],ptr);
        ptr = current;
    }
  data = ptr;
    x.clear();
    return *this;
}

void Stack::push(int x){
    if(data == NULL)
        data = new node(x,NULL);
    else{
        node *p = new node(data->num,data->next);
        delete(data);
        data = new node(x,p);
    }
}
void Stack::pop(){
    node *p = data->next;
    delete(data);
    data = p;
}

int Stack::top()const {
    return data->num;
}

bool Stack::empty()const{
    return data==NULL;
}

void Stack::clear(){
    node *current = data;
    node *temp;
  while(current!=NULL){
        temp = current->next;
        delete(current);
        current = temp;
    }
    data=NULL;
}