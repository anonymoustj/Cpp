#include <vector>
#include <string>
#include <iostream>

using namespace std;

int main(){
	vector<string> circle;
	vector<string>::iterator it1;
	string str;
	string str1;
	string str2;
	string str3;
	int n;
	while(1)
	{
		string ss;
		cin>>ss;
    if(cin.eof())
			break;
		circle.push_back(ss);
		n++;
		
	}
	for(it1 = circle.begin();(it1+1) != circle.end();it1++){
			cout << *it1 << " ";
		}cout << *it1 << endl;
	for(int i = 0;i < n-1;i++){
		it1 = circle.begin();
		str2 = *it1;
		for(it1 = circle.begin();(it1+1) != circle.end();it1++){
			*it1 = *(it1+1);
		}
		*it1 = str2;
		for(it1 = circle.begin();(it1+1) != circle.end();it1++){
			cout << *it1 << " ";
		}cout << *it1 << endl;
	}
}