# [STL]Cycling the words

# Cycling the words

# Description
<p>Given a line contains N words, print the N lines. The first line is the same as the input. After printing each line, the first word of this line in put to the end of the next line.</p>

# Input
<p>A line contains N words seperated by one blank. N is not given in the problem: you need to count the number of words in the input line to find it out. The line contains less than 100 characters.</p>

# Output
<p>N lines.<br />
The first line equals the input.<br />
For the rest N-1 lines, the first word in a line in put to the end in the next line. There is one space between words.</p>

# Sample_Input
```
Please think about it carefully
```

# Sample_Ouput
```
Please think about it carefully
think about it carefully Please
about it carefully Please think
it carefully Please think about
carefully Please think about it

```

# Hint


