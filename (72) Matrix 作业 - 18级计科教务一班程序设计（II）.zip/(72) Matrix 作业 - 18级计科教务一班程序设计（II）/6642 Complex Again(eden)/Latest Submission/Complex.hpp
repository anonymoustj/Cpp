
#include<iostream>
using namespace std;class Complex {

    //A friend function to print Complex numbers like a+bi where a is the real part and b is the imaginary part
  friend ostream& operator <<(ostream& out, const Complex& c) {
    if (c.real == 0 && c.imag != 0) {
           out << c.imag << 'i' << endl;
           return out;
         }
         out << c.real;
         if (c.imag != 0) {
           if (c.imag > 0)
             out << "+" << c.imag;
           else
             out << c.imag;
           out << 'i' << endl;
         }
         return out;
  }

friend Complex& operator +(const Complex &a,const Complex &b)
{
	Complex *c;
	c=new Complex;
	c->real=a.real+b.real;
	c->imag=a.imag+b.imag;
	return *c;
}
friend Complex& operator +=(Complex &a,const Complex& b)
{
	a.real=a.real+b.real;
	a.imag=a.imag+b.imag;
	return a;
}
friend Complex& operator -(const Complex& a,const Complex &b)
{
	Complex *c;
	c=new Complex;
	c->real=a.real-b.real;
	c->imag=a.imag-b.imag;
	return *c;
}
friend Complex& operator -=(Complex &a,const Complex &b)
{
	a.real=a.real-b.real;
	a.imag=a.imag-b.imag;
	return a;
}
friend Complex& operator *(const Complex &a,const Complex& b)
{
	Complex *c;
	c=new Complex;
	c->real=a.real*b.real-a.imag*b.imag;
	c->imag=a.imag*b.real+a.real*b.imag;
	return *c;
}
friend Complex& operator *=(Complex& a,const Complex& b)
{
  Complex c;
	c.real=a.real*b.real-a.imag*b.imag;
	c.imag=a.imag*b.real+a.real*b.imag;
  a=c;
	return a;
}
friend Complex& operator /(const Complex &a,const Complex& b)
{
	Complex *c;
	c=new Complex;
	c->real=(a.real*b.real+a.imag*b.imag)/(b.imag*b.imag+b.real*b.real);
	c->imag=(a.imag*b.real-a.real*b.imag)/(b.imag*b.imag+b.real*b.real);
	return *c;
}

friend Complex& operator /=(Complex& a,const Complex &b)
{
	Complex c;
	c.real=(a.real*b.real+a.imag*b.imag)/(b.imag*b.imag+b.real*b.real);
	c.imag=(a.imag*b.real-a.real*b.imag)/(b.imag*b.imag+b.real*b.real);
	a=c;
	return a;
}

friend bool operator ==(const Complex &a,const Complex& b)
{
	if(a.imag==b.imag&&a.real==b.real)
	return true;
	return false;
}
friend bool operator !=(const Complex &a,const Complex &b)
{
	if(a.imag==b.imag&&a.real==b.real)
	return false;
	return true;
}
public:
   Complex(double = 0.0, double = 0.0);

   //Some function about operator overloading.

   void SetReal(double re){real = re;}
   void SetImag(double im){imag = im;}
private:
   double real; 
   double imag; 
};