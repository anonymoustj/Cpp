#include"Complex.hpp"
Complex::Complex(double n, double m)
{
	real=n;
	imag=m;
}