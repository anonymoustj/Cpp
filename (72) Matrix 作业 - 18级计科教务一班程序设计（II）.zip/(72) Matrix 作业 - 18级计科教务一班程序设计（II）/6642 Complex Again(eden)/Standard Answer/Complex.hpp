#ifndef COMPLEX_H
#define COMPLEX_H
#include <iostream>
using namespace std;
class Complex {
  friend ostream& operator <<(ostream& out, const Complex& c) {
    if (c.real == 0 && c.imag != 0) {
 		  out << c.imag << 'i' << endl;
   		return out;
 		}
 		out << c.real;
 		if (c.imag != 0) {
   		if (c.imag > 0)
     		out << "+" << c.imag;
   		else
     		out << c.imag;
   		out << 'i' << endl;
 		}
 		return out;
  }
 
 public:
  Complex(double = 0, double = 0);
  Complex(const Complex& otherComplex);
 
  Complex& operator = (const Complex& otherComplex);
  Complex& operator += (const Complex& otherComplex);
  Complex& operator -= (const Complex& otherComplex);
  Complex& operator *= (const Complex& otherComplex);
  Complex& operator /= (const Complex& otherComplex);
 
  Complex operator +(const Complex&);
  Complex operator -(const Complex&);
  Complex operator *(const Complex&);
  Complex operator /(const Complex&);
 
  bool operator == (const Complex& otherComplex);
  bool operator != (const Complex& otherComplex);
 
  void SetReal(double re) {
    real = re;
  }
  void SetImag(double im) {
    imag = im;
  }
 
 private:
  double real;
  double imag;
};
#endif