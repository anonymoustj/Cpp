#include<iostream>
#include<vector>
using namespace std;
int main(){
    vector<int> vec(10);
    vector<int>::iterator iter;
    for(int i = 0; i <= 9; i++){
        vec[i] = i;
    }

	for(iter=vec.begin();iter!=vec.end();iter++)
	{
		*iter=*iter+1;
	}
    // your code

	for(int i=0;i<3;i++)
    vec.insert(vec.begin()+1,100);
    
    // your code


    vec.erase(vec.end()-1);
    vec.insert(vec.end(),200);
    for(iter=vec.begin();iter!=vec.end();iter++)
    {
		cout<<*iter<<" ";
	}
    // your code


    // ??????????200 
    // your code

    // ??iter??vec
    // your code



    return 0;
}