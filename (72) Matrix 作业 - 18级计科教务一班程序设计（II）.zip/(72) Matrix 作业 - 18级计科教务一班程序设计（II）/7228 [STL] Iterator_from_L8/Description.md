# [STL] Iterator_from_L8

## Description
Implement the following operation with iterator
```C++
int main(){
    vector<int> vec(10);
    vector<int>::iterator iter;
    for(int i = 0; i <= 9; i++){
        vec[i] = i;
    }


    // 用iter将每一个元素加1
    // your code

    // 在第1个元素前面插入3个100
    // your code


    // 删除最后一个元素
    // your code


    // 在最后的位置插入元素200 
    // your code

    // 利用iter输出vec
    // your code
    


    return 0;
}

```

## output
1 100 100 100 2 3 4 5 6 7 8 9 200 