#include <iostream>
#include "Stack.hpp"
using namespace std;

Stack::Stack(){
	this->data = NULL;
}
Stack::Stack(const Stack& other){
	this->data = new struct node();
	node *p1 = this->data, *p2 = other.data;
	if(p2!=NULL)
	{
		while(p2->next!=NULL)
		{
			p1->num = p2->num;
			p1->next = new node();
			p1 = p1->next;
			p2 = p2->next;
		}
		p1->num = p2->num;
	}
	else
	{
		delete this->data;
		this->data = NULL;
	}
}
Stack::~Stack(){
	clear();
}
bool Stack::empty() const{
	if(data == NULL) return true;
	else return false;
}
void Stack::push(int n){
		node *p1 = new node();
		p1->num = n;
		p1->next = data;
		this->data = p1;
}
int Stack::top() const{
	if(data == NULL) return 0;
	else return data->num;
}
void Stack::pop(){
	if(data == NULL) return;
	node *temp = data;
	data = data->next;
	delete temp;
}
void Stack::clear(){
	while(!empty()) pop();
}
Stack Stack::operator=(const Stack &st){

	if(this == &st) return *this;
	if(data != NULL){
		clear();
	}
	if(st.data == NULL){
		data = NULL;
		return *this;
	}
	else{
node *p1,*top;
	p1 = st.data;
	top = NULL;
	while(p1){
		if(top == NULL){
			data = new node(p1->num);
			top = data;
		}
		else{
			data->next = new node(p1->num);
			data = data->next;
		}
		p1 = p1->next;
	}
	data = top;
	return *this;
}
}
std::ostream& operator<<(std::ostream& os, const Stack& s){
	Stack p;
	p.data = s.data;
	os << "[";
	while(p.data){
		os << p.data->num;
		if(p.data->next != NULL)
		os << ',';
		
		p.data = p.data->next;
	}
	os << "]"  ;
	return os;
}