#include<iostream>
#include<string>
#include<set>
#include<algorithm>
using namespace std;

int sumOfIntersection(const set<int>& set1, const set<int>& set2)
{
	int sum=0;
	set<int>::iterator iter,i;
	for(iter=set1.begin();iter!=set1.end();iter++)
	{
		for(i=set2.begin();i!=set2.end();i++)
		{
			if((*iter)==(*i))
			{
				sum+=*i;
				break;
			}
		}
	}
	return sum;
};