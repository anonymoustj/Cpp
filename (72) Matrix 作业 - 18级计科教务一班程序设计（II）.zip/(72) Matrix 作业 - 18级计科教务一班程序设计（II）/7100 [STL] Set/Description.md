# [STL] Set

# Set

# Description
<div>&nbsp;</div>
<div style="text-indent: 21pt"><font size="3">Please implement the function&nbsp;<span style="color: #0000ff">int sumOfIntersection(const set&lt;int&gt;&amp; set1, const set&lt;int&gt;&amp; set2)</span>, which&nbsp;returns the sum of all the elements that both appear in set1 and set2.</font></div>
<div>&nbsp;</div>
<div style="text-indent: 21pt"><font size="3">Your submitted source code should&nbsp;include the implementation of the sumOfIntersection function.</font></div>
<div style="text-indent: 21pt"><font size="3">No main() function should be included.</font></div>
<p>&nbsp;</p>

# Input


# Output


# Sample_Input
```
set1: 1 3 5
set2: 1
```

# Sample_Ouput
```
1
```

# Hint


