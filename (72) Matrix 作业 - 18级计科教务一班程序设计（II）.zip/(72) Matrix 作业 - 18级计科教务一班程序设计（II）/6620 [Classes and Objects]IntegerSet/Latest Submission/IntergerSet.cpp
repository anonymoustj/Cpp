#include <iostream>
#include "IntegerSet.h"
using namespace std;

void IntegerSet::emptySet(){
	int i = 0;
	for(i = 0;i < 101;i++){
		set[i] = 0;
	}
}
IntegerSet::IntegerSet(int s[],int l){
	int i = 0,j;
	for(i = 0;i < 101;i++){
		set[i] = 0;
	}
	for(j = 0;j < l;j++){
    if(s[j] >= 0&&s[j] <= 100){
			set[s[j]] = 1;
    }
    else{
    	cout << "Invalid insert attempted!" << endl;
	}
}
}
IntegerSet IntegerSet::unionOfSets(const IntegerSet& a){
	int i;
	IntegerSet temp;
	for(i = 0;i < 101;i++){
		if(this->set[i] == 0&&a.set[i] == 0){
			temp.set[i] = 0;
		}
		else temp.set[i] = 1;
	}
	return temp;
}
IntegerSet IntegerSet::intersectionOfSets(const IntegerSet& a){
	int i;
	IntegerSet temp;
	for(i = 0;i < 101;i++){
		if(this->set[i] == 1&&a.set[i] == 1){
			temp.set[i] = 1;
		}
		else temp.set[i] = 0;
	}
	return temp;
}
void IntegerSet::insertElement(int element){
	if(element >= 0&&element <= 100){
		set[element] = 1;
	}
	else{
		cout << "Invalid insert attempted!" << endl; 
	}
}
void IntegerSet::deleteElement(int element){
	if(element >= 0&&element <= 100){
		set[element] = 0;
	}
	else{
		cout << "Invalid delete attempted!" << endl; 
	}
}
bool IntegerSet::isEqualTo(const IntegerSet& a) const{
	int i;
	for(i = 0;i < 101;i++){
		if(this->set[i] != a.set[i]) return false;
	}
	return true;
}